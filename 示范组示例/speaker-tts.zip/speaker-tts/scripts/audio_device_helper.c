#include <CoreAudio/CoreAudio.h>
#include <CoreFoundation/CoreFoundation.h>
#include <stdbool.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <strings.h>

typedef struct {
    AudioDeviceID id;
    char name[512];
    char uid[512];
    unsigned int output_channels;
    bool is_default_output;
    bool is_default_system_output;
} DeviceSummary;

static void print_error_json(const char *message) {
    fprintf(stderr, "{\"success\":false,\"error\":\"");
    for (const char *p = message; *p; ++p) {
        if (*p == '"' || *p == '\\') {
            fputc('\\', stderr);
        }
        if (*p == '\n') {
            fputs("\\n", stderr);
        } else {
            fputc(*p, stderr);
        }
    }
    fprintf(stderr, "\"}\n");
}

static void print_json_string(const char *value) {
    fputc('"', stdout);
    for (const char *p = value; *p; ++p) {
        if (*p == '"' || *p == '\\') {
            fputc('\\', stdout);
            fputc(*p, stdout);
        } else if (*p == '\n') {
            fputs("\\n", stdout);
        } else {
            fputc(*p, stdout);
        }
    }
    fputc('"', stdout);
}

static bool get_system_device(AudioObjectPropertySelector selector, AudioDeviceID *device_id, char *error, size_t error_size) {
    AudioObjectPropertyAddress address = {
        .mSelector = selector,
        .mScope = kAudioObjectPropertyScopeGlobal,
        .mElement = kAudioObjectPropertyElementMain,
    };
    UInt32 size = sizeof(AudioDeviceID);
    OSStatus status = AudioObjectGetPropertyData(
        kAudioObjectSystemObject,
        &address,
        0,
        NULL,
        &size,
        device_id
    );
    if (status != noErr) {
        snprintf(error, error_size, "AudioObjectGetPropertyData(system selector %u) failed: %d", (unsigned int)selector, (int)status);
        return false;
    }
    return true;
}

static bool get_string_property(AudioObjectID object_id, AudioObjectPropertySelector selector, AudioObjectPropertyScope scope, char *buffer, size_t buffer_size, char *error, size_t error_size) {
    AudioObjectPropertyAddress address = {
        .mSelector = selector,
        .mScope = scope,
        .mElement = kAudioObjectPropertyElementMain,
    };
    CFStringRef value = NULL;
    UInt32 size = sizeof(CFStringRef);
    OSStatus status = AudioObjectGetPropertyData(
        object_id,
        &address,
        0,
        NULL,
        &size,
        &value
    );
    if (status != noErr) {
        snprintf(error, error_size, "AudioObjectGetPropertyData(string selector %u) failed: %d", (unsigned int)selector, (int)status);
        return false;
    }
    if (value == NULL) {
        snprintf(error, error_size, "empty string property for selector %u", (unsigned int)selector);
        return false;
    }
    Boolean ok = CFStringGetCString(value, buffer, buffer_size, kCFStringEncodingUTF8);
    CFRelease(value);
    if (!ok) {
        snprintf(error, error_size, "CFStringGetCString failed for selector %u", (unsigned int)selector);
        return false;
    }
    return true;
}

static unsigned int get_output_channel_count(AudioDeviceID device_id, char *error, size_t error_size) {
    AudioObjectPropertyAddress address = {
        .mSelector = kAudioDevicePropertyStreamConfiguration,
        .mScope = kAudioDevicePropertyScopeOutput,
        .mElement = kAudioObjectPropertyElementMain,
    };
    if (!AudioObjectHasProperty(device_id, &address)) {
        return 0;
    }

    UInt32 size = 0;
    OSStatus status = AudioObjectGetPropertyDataSize(device_id, &address, 0, NULL, &size);
    if (status != noErr) {
        snprintf(error, error_size, "AudioObjectGetPropertyDataSize(stream config) failed: %d", (int)status);
        return 0;
    }
    if (size == 0) {
        return 0;
    }

    AudioBufferList *buffer_list = (AudioBufferList *)malloc(size);
    if (buffer_list == NULL) {
        snprintf(error, error_size, "malloc failed for AudioBufferList");
        return 0;
    }

    status = AudioObjectGetPropertyData(device_id, &address, 0, NULL, &size, buffer_list);
    if (status != noErr) {
        free(buffer_list);
        snprintf(error, error_size, "AudioObjectGetPropertyData(stream config) failed: %d", (int)status);
        return 0;
    }

    unsigned int channels = 0;
    for (UInt32 i = 0; i < buffer_list->mNumberBuffers; ++i) {
        channels += buffer_list->mBuffers[i].mNumberChannels;
    }
    free(buffer_list);
    return channels;
}

static bool get_all_devices(AudioDeviceID **devices, UInt32 *count, char *error, size_t error_size) {
    AudioObjectPropertyAddress address = {
        .mSelector = kAudioHardwarePropertyDevices,
        .mScope = kAudioObjectPropertyScopeGlobal,
        .mElement = kAudioObjectPropertyElementMain,
    };

    UInt32 size = 0;
    OSStatus status = AudioObjectGetPropertyDataSize(
        kAudioObjectSystemObject,
        &address,
        0,
        NULL,
        &size
    );
    if (status != noErr) {
        snprintf(error, error_size, "AudioObjectGetPropertyDataSize(devices) failed: %d", (int)status);
        return false;
    }

    *count = size / sizeof(AudioDeviceID);
    *devices = (AudioDeviceID *)malloc(size);
    if (*devices == NULL) {
        snprintf(error, error_size, "malloc failed for device list");
        return false;
    }

    status = AudioObjectGetPropertyData(
        kAudioObjectSystemObject,
        &address,
        0,
        NULL,
        &size,
        *devices
    );
    if (status != noErr) {
        free(*devices);
        *devices = NULL;
        snprintf(error, error_size, "AudioObjectGetPropertyData(devices) failed: %d", (int)status);
        return false;
    }
    return true;
}

static bool collect_output_devices(DeviceSummary **summaries, size_t *summary_count, char *error, size_t error_size) {
    AudioDeviceID default_output = 0;
    AudioDeviceID default_system_output = 0;
    if (!get_system_device(kAudioHardwarePropertyDefaultOutputDevice, &default_output, error, error_size)) {
        return false;
    }
    if (!get_system_device(kAudioHardwarePropertyDefaultSystemOutputDevice, &default_system_output, error, error_size)) {
        return false;
    }

    AudioDeviceID *device_ids = NULL;
    UInt32 device_count = 0;
    if (!get_all_devices(&device_ids, &device_count, error, error_size)) {
        return false;
    }

    DeviceSummary *items = (DeviceSummary *)calloc(device_count, sizeof(DeviceSummary));
    if (items == NULL) {
        free(device_ids);
        snprintf(error, error_size, "calloc failed for device summaries");
        return false;
    }

    size_t write_index = 0;
    for (UInt32 i = 0; i < device_count; ++i) {
        char local_error[256] = {0};
        unsigned int output_channels = get_output_channel_count(device_ids[i], local_error, sizeof(local_error));
        if (output_channels == 0) {
            continue;
        }

        DeviceSummary summary = {0};
        summary.id = device_ids[i];
        summary.output_channels = output_channels;
        summary.is_default_output = (device_ids[i] == default_output);
        summary.is_default_system_output = (device_ids[i] == default_system_output);

        if (!get_string_property(device_ids[i], kAudioObjectPropertyName, kAudioObjectPropertyScopeGlobal, summary.name, sizeof(summary.name), error, error_size)) {
            free(device_ids);
            free(items);
            return false;
        }
        if (!get_string_property(device_ids[i], kAudioDevicePropertyDeviceUID, kAudioObjectPropertyScopeGlobal, summary.uid, sizeof(summary.uid), error, error_size)) {
            free(device_ids);
            free(items);
            return false;
        }

        items[write_index++] = summary;
    }

    free(device_ids);
    *summaries = items;
    *summary_count = write_index;
    return true;
}

static void print_device_summary(const DeviceSummary *device) {
    printf("{\"id\":%u,\"name\":", (unsigned int)device->id);
    print_json_string(device->name);
    printf(",\"uid\":");
    print_json_string(device->uid);
    printf(",\"outputChannels\":%u,\"isDefaultOutput\":%s,\"isDefaultSystemOutput\":%s}",
           device->output_channels,
           device->is_default_output ? "true" : "false",
           device->is_default_system_output ? "true" : "false");
}

static void print_device_list(const DeviceSummary *devices, size_t count) {
    printf("{\"devices\":[");
    for (size_t i = 0; i < count; ++i) {
        if (i > 0) {
            printf(",");
        }
        print_device_summary(&devices[i]);
    }
    printf("]}\n");
}

static void print_current_defaults(const DeviceSummary *devices, size_t count) {
    printf("{\"defaultOutput\":");
    bool found_output = false;
    for (size_t i = 0; i < count; ++i) {
        if (devices[i].is_default_output) {
            print_device_summary(&devices[i]);
            found_output = true;
            break;
        }
    }
    if (!found_output) {
        printf("null");
    }

    printf(",\"defaultSystemOutput\":");
    bool found_system_output = false;
    for (size_t i = 0; i < count; ++i) {
        if (devices[i].is_default_system_output) {
            print_device_summary(&devices[i]);
            found_system_output = true;
            break;
        }
    }
    if (!found_system_output) {
        printf("null");
    }
    printf("}\n");
}

static const DeviceSummary *find_device_by_name(const DeviceSummary *devices, size_t count, const char *name, char *error, size_t error_size) {
    if (name == NULL || *name == '\0') {
        snprintf(error, error_size, "device name is required");
        return NULL;
    }

    for (size_t i = 0; i < count; ++i) {
        if (strcmp(devices[i].name, name) == 0) {
            return &devices[i];
        }
    }
    for (size_t i = 0; i < count; ++i) {
        if (strcasecmp(devices[i].name, name) == 0) {
            return &devices[i];
        }
    }

    const DeviceSummary *match = NULL;
    for (size_t i = 0; i < count; ++i) {
        if (strcasestr(devices[i].name, name) != NULL) {
            if (match != NULL) {
                snprintf(error, error_size, "multiple output devices matched name: %s", name);
                return NULL;
            }
            match = &devices[i];
        }
    }
    if (match != NULL) {
        return match;
    }

    snprintf(error, error_size, "output device not found: %s", name);
    return NULL;
}

static bool set_system_device(AudioObjectPropertySelector selector, AudioDeviceID device_id, char *error, size_t error_size) {
    AudioObjectPropertyAddress address = {
        .mSelector = selector,
        .mScope = kAudioObjectPropertyScopeGlobal,
        .mElement = kAudioObjectPropertyElementMain,
    };
    UInt32 size = sizeof(AudioDeviceID);
    OSStatus status = AudioObjectSetPropertyData(
        kAudioObjectSystemObject,
        &address,
        0,
        NULL,
        size,
        &device_id
    );
    if (status != noErr) {
        snprintf(error, error_size, "AudioObjectSetPropertyData(selector %u) failed: %d", (unsigned int)selector, (int)status);
        return false;
    }
    return true;
}

static const char *arg_value(int argc, char **argv, const char *flag) {
    for (int i = 2; i < argc - 1; ++i) {
        if (strcmp(argv[i], flag) == 0) {
            return argv[i + 1];
        }
    }
    return NULL;
}

int main(int argc, char **argv) {
    if (argc < 2) {
        print_error_json("missing command");
        return 1;
    }

    char error[512] = {0};
    DeviceSummary *devices = NULL;
    size_t device_count = 0;

    if (!collect_output_devices(&devices, &device_count, error, sizeof(error))) {
        print_error_json(error);
        return 1;
    }

    const char *command = argv[1];
    if (strcmp(command, "list-output") == 0) {
        print_device_list(devices, device_count);
        free(devices);
        return 0;
    }

    if (strcmp(command, "current-output") == 0) {
        print_current_defaults(devices, device_count);
        free(devices);
        return 0;
    }

    if (strcmp(command, "set-defaults") == 0) {
        const char *output_name = arg_value(argc, argv, "--output-name");
        const char *system_name = arg_value(argc, argv, "--system-name");
        if (output_name == NULL && system_name == NULL) {
            free(devices);
            print_error_json("set-defaults requires --output-name and/or --system-name");
            return 1;
        }

        if (output_name != NULL) {
            const DeviceSummary *device = find_device_by_name(devices, device_count, output_name, error, sizeof(error));
            if (device == NULL || !set_system_device(kAudioHardwarePropertyDefaultOutputDevice, device->id, error, sizeof(error))) {
                free(devices);
                print_error_json(error);
                return 1;
            }
        }

        if (system_name != NULL) {
            const DeviceSummary *device = find_device_by_name(devices, device_count, system_name, error, sizeof(error));
            if (device == NULL || !set_system_device(kAudioHardwarePropertyDefaultSystemOutputDevice, device->id, error, sizeof(error))) {
                free(devices);
                print_error_json(error);
                return 1;
            }
        }

        free(devices);
        devices = NULL;
        device_count = 0;
        if (!collect_output_devices(&devices, &device_count, error, sizeof(error))) {
            print_error_json(error);
            return 1;
        }
        print_current_defaults(devices, device_count);
        free(devices);
        return 0;
    }

    free(devices);
    print_error_json("unknown command");
    return 1;
}
