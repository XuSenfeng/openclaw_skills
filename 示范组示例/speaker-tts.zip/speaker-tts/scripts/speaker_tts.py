#!/usr/bin/env python3

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import time
from pathlib import Path
from typing import Any


SCRIPT_DIR = Path(__file__).resolve().parent
SKILL_ROOT = SCRIPT_DIR.parent
AUDIO_HELPER_SOURCE = SCRIPT_DIR / "audio_device_helper.c"
AUDIO_HELPER_BINARY = SCRIPT_DIR / "audio_device_helper"


def resolve_state_file() -> Path:
    candidates = []
    explicit_root = os.environ.get("OPENCLAW_STATE_DIR")
    if explicit_root:
        candidates.append(Path(explicit_root) / "speaker-tts")
    candidates.append(Path.home() / ".openclaw" / "state" / "speaker-tts")
    candidates.append(Path("/tmp/openclaw-state/speaker-tts"))

    for candidate in candidates:
        try:
            candidate.mkdir(parents=True, exist_ok=True)
            return candidate / "status.json"
        except OSError:
            continue

    raise RuntimeError("state_dir_unavailable")


STATE_FILE = resolve_state_file()
STATE_DIR = STATE_FILE.parent


def emit(payload: dict[str, Any], exit_code: int) -> int:
    payload.setdefault("success", exit_code == 0)
    payload.setdefault("exit_code", exit_code)
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return exit_code


def save_state(payload: dict[str, Any]) -> None:
    STATE_DIR.mkdir(parents=True, exist_ok=True)
    with STATE_FILE.open("w", encoding="utf-8") as fh:
        json.dump(payload, fh, ensure_ascii=False, indent=2)


def load_state() -> dict[str, Any]:
    if not STATE_FILE.exists():
        return {
            "status": "idle",
            "last_text": None,
            "last_voice": None,
            "updated_at": None,
        }
    with STATE_FILE.open("r", encoding="utf-8") as fh:
        return json.load(fh)


def list_voices() -> list[str]:
    result = subprocess.run(["say", "-v", "?"], capture_output=True, text=True)
    if result.returncode != 0:
        return []
    voices: list[str] = []
    for line in result.stdout.splitlines():
        stripped = line.strip()
        if not stripped:
            continue
        voices.append(stripped.split()[0])
    return voices


def run_audio_helper(args: list[str]) -> subprocess.CompletedProcess[str]:
    compiler = shutil.which("clang") or shutil.which("cc")
    if compiler is None:
        raise RuntimeError("c_compiler_not_found")
    if not AUDIO_HELPER_SOURCE.exists():
        raise RuntimeError("audio_helper_source_not_found")
    if (
        not AUDIO_HELPER_BINARY.exists()
        or AUDIO_HELPER_BINARY.stat().st_mtime < AUDIO_HELPER_SOURCE.stat().st_mtime
    ):
        compile_result = subprocess.run(
            [
                compiler,
                str(AUDIO_HELPER_SOURCE),
                "-framework",
                "CoreAudio",
                "-framework",
                "CoreFoundation",
                "-o",
                str(AUDIO_HELPER_BINARY),
            ],
            capture_output=True,
            text=True,
        )
        if compile_result.returncode != 0:
            raise RuntimeError(compile_result.stderr.strip() or "audio_helper_compile_failed")
    return subprocess.run(
        [str(AUDIO_HELPER_BINARY), *args],
        capture_output=True,
        text=True,
    )


def parse_json_output(result: subprocess.CompletedProcess[str]) -> dict[str, Any]:
    text = (result.stdout or "").strip()
    if not text:
        return {}
    return json.loads(text)


def current_audio_defaults() -> dict[str, Any]:
    result = run_audio_helper(["current-output"])
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or "audio_current_output_failed")
    return parse_json_output(result)


def set_audio_defaults(output_name: str | None, system_name: str | None) -> dict[str, Any]:
    helper_args = ["set-defaults"]
    if output_name:
        helper_args.extend(["--output-name", output_name])
    if system_name:
        helper_args.extend(["--system-name", system_name])
    result = run_audio_helper(helper_args)
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or "audio_set_output_failed")
    return parse_json_output(result)


def list_output_devices() -> dict[str, Any]:
    result = run_audio_helper(["list-output"])
    if result.returncode != 0:
        raise RuntimeError(result.stderr.strip() or "audio_list_output_failed")
    return parse_json_output(result)


def choose_voice(requested: str | None) -> str | None:
    voices = list_voices()
    if requested and requested != "auto":
        return requested
    preferred = ("Tingting", "Sinji", "Meijia")
    for name in preferred:
        if name in voices:
            return name
    return voices[0] if voices else None


def resolve_requested_device(requested: str | None) -> str | None:
    if requested and requested not in {"auto", "system-default"}:
        return requested

    env_device = os.environ.get("OPENCLAW_TTS_OUTPUT_DEVICE")
    if env_device and env_device not in {"auto", "system-default"}:
        return env_device

    return None


def cmd_speak(args: argparse.Namespace) -> int:
    if shutil.which("say") is None:
        payload = {"success": False, "error": "say_command_not_found"}
        save_state(
            {
                "status": "error",
                "last_text": args.text,
                "last_voice": None,
                "updated_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
                "last_result": payload,
            }
        )
        return emit(payload, 1)

    voice = choose_voice(args.voice)
    requested_device = resolve_requested_device(args.device)
    original_defaults: dict[str, Any] | None = None
    routed_defaults: dict[str, Any] | None = None
    restore_error: str | None = None

    if requested_device:
        try:
            original_defaults = current_audio_defaults()
            routed_defaults = set_audio_defaults(requested_device, requested_device)
        except RuntimeError as exc:
            payload = {
                "success": False,
                "error": "audio_device_switch_failed",
                "details": str(exc),
                "requested_device": requested_device,
            }
            save_state(
                {
                    "status": "error",
                    "last_text": args.text,
                    "last_voice": voice,
                    "last_device": requested_device,
                    "updated_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
                    "last_result": payload,
                }
            )
            return emit(payload, 1)

    cmd = ["say"]
    if voice:
        cmd.extend(["-v", voice])
    if args.rate:
        cmd.extend(["-r", str(args.rate)])
    cmd.append(args.text)

    started = time.perf_counter()
    try:
        result = subprocess.run(cmd, capture_output=True, text=True)
    finally:
        if requested_device and original_defaults:
            default_output = original_defaults.get("defaultOutput") or {}
            default_system_output = original_defaults.get("defaultSystemOutput") or {}
            try:
                set_audio_defaults(
                    default_output.get("name"),
                    default_system_output.get("name"),
                )
            except RuntimeError as exc:
                restore_error = str(exc)
    elapsed_ms = round((time.perf_counter() - started) * 1000, 2)

    payload = {
        "success": result.returncode == 0,
        "text": args.text,
        "voice": voice,
        "rate": args.rate,
        "device": requested_device or "system-default",
        "audio_route": routed_defaults,
        "restore_error": restore_error,
        "elapsed_ms": elapsed_ms,
        "stderr": result.stderr,
    }
    save_state(
        {
            "status": "ok" if result.returncode == 0 else "error",
            "last_text": args.text,
            "last_voice": voice,
            "last_device": requested_device or "system-default",
            "updated_at": time.strftime("%Y-%m-%dT%H:%M:%S%z"),
            "last_result": payload,
        }
    )
    return emit(payload, result.returncode)


def cmd_status(_: argparse.Namespace) -> int:
    return emit(load_state(), 0)


def cmd_list_devices(_: argparse.Namespace) -> int:
    try:
        payload = list_output_devices()
    except RuntimeError as exc:
        return emit({"success": False, "error": str(exc)}, 1)
    payload["selected_default"] = os.environ.get("OPENCLAW_TTS_OUTPUT_DEVICE", "system-default")
    return emit(payload, 0)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Local speaker TTS skill using macOS say.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    p_speak = subparsers.add_parser("speak", help="Speak text through the local speaker.")
    p_speak.add_argument("--text", required=True)
    p_speak.add_argument("--voice", default="auto")
    p_speak.add_argument("--rate", type=int, default=180)
    p_speak.add_argument("--device", default="auto")
    p_speak.set_defaults(func=cmd_speak)

    p_status = subparsers.add_parser("speak_status", help="Get the latest speaker status.")
    p_status.set_defaults(func=cmd_status)

    p_list = subparsers.add_parser("list_devices", help="List available audio output devices.")
    p_list.set_defaults(func=cmd_list_devices)

    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
