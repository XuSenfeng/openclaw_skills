---
name: speaker-tts
description: 本地语音播报 skill。负责把文本通过指定音频输出设备播报，默认走摄像头喇叭，不提供录音或系统级任意音频控制。
---

# speaker-tts 技能

先读这一条，再做别的：

- 这是本地 skill，不是 agent。
- 统一通过 `scripts/speaker_tts` 调用。
- 第一版只做 TTS 播报，不做录音、转写、任意播放器控制。
- 当前机器默认输出设备固定为 `UGREEN Camera Audio`，也可在调用时显式覆盖。
- 只允许播报文本，不允许把它扩展成系统级音频自动化工具。

## 统一启动器

```bash
TOOL="$HOME/.openclaw/skills/speaker-tts/scripts/speaker_tts"
```

所有输出均为 JSON。

## speak

```bash
$TOOL speak --text "抓取开始"

$TOOL speak --text "抓取失败，请检查目标位置" --voice Tingting --rate 180

$TOOL speak --text "抓取开始" --device "UGREEN Camera Audio"
```

返回：

- 是否成功
- 实际播报文本
- 实际语音
- 速率
- 实际输出设备
- 耗时

## list_devices

```bash
$TOOL list_devices
```

返回当前机器可见的音频输出设备，以及 skill 默认使用的设备。

## speak_status

```bash
$TOOL speak_status
```

返回最近一次播报状态。

## OpenClaw 约束

- 只负责播报文本。
- 不允许把它用于任意音频文件播放、音量控制或其他系统控制。

## 自然语言示例

- “播报：抓取开始”
- “播报：抓取失败，请人工检查”
- “看看刚才播报有没有成功”
