---
name: lerobot
description: OpenClaw 机械臂基础控制 skill。通过统一启动器完成环境自检、串口发现、校准、单关节控制、模板动作回放、活动关节回放，以及 follower 状态读取。
---

# lerobot 技能

先读这一条，再做别的：

- 这是本地 skill，不是 agent。
- 统一通过 `scripts/lerobot_skill` 调用，不要直接拼装底层危险命令。
- 自动抓取主链路只支持单个 follower 机械臂。
- leader/follower 双臂跟随与录制能力仍保留，但不属于视觉抓取主链路。
- 如果用户只是要抓取/对准/放置，不要直接调用本 skill 的底层脚本，应优先走 `vision-grasp-arm`。

## 统一启动器

固定入口：

```bash
TOOL="$HOME/.openclaw/skills/lerobot/scripts/lerobot_skill"
```

当前支持的高层命令：

- `env-check`
- `find-port`
- `calibrate`
- `move-joint`
- `replay-template`
- `replay-moving-joints`
- `replay-sequence`
- `teleoperate`
- `get-state`

所有输出均为 JSON。

## 环境自检

```bash
$TOOL env-check
```

会检查：

- `conda` / `mamba` 是否可用
- `lerobot` 环境是否存在
- 关键 Python 依赖是否可导入
- 当前可见的机械臂串口

如果失败，JSON 的 `issues` 会给出明确原因，例如：

- `missing_conda_or_mamba`
- `missing_lerobot_env`
- `missing_python_dependencies`
- `no_visible_robot_ports`

## 串口发现

```bash
$TOOL find-port
```

返回当前可见串口列表，以及建议的：

- `suggested.follower`
- `suggested.leader`

如果没有显式传端口，后续命令会优先：

1. 读取参数里的端口
2. 读取环境变量 `LEROBOT_FOLLOWER_PORT` / `LEROBOT_LEADER_PORT`
3. 自动用建议串口

## 校准

```bash
$TOOL calibrate

$TOOL calibrate --follower-port /dev/tty.usbmodemFOLLOWER --leader-port /dev/tty.usbmodemLEADER
```

当前校准入口会依次校准 follower 和 leader。若只接了单臂，不要直接运行该命令。

## 单关节微调

```bash
$TOOL move-joint --joint shoulder_pan --value 2 --mode delta

$TOOL move-joint --joint wrist_flex --value 35 --mode target --follower-port /dev/tty.usbmodemFOLLOWER
```

可用关节：

- `shoulder_pan`
- `shoulder_lift`
- `elbow_flex`
- `wrist_flex`
- `wrist_roll`
- `gripper`

## 模板动作回放

完整回放一个数据集：

```bash
$TOOL replay-template --dataset zhuaqu
```

只回放活动关节：

```bash
$TOOL replay-template --dataset zhuaqu --moving-joints-only
```

更明确地走活动关节回放入口：

```bash
$TOOL replay-moving-joints --dataset zhuaqu --movement-threshold 2
```

常用参数：

- `--episode`
- `--fps`
- `--max-relative-target`
- `--movement-threshold`
- `--active-joints`
- `--dry-run`

## 固定顺序模板回放

如果要顺序执行预设的 “zhuaqu -> dao”：

```bash
$TOOL replay-sequence

$TOOL replay-sequence --approach-dataset zhuaqu --place-dataset dao
```

## 双臂跟随

```bash
$TOOL teleoperate

$TOOL teleoperate --follower-port /dev/tty.usbmodemFOLLOWER --leader-port /dev/tty.usbmodemLEADER
```

这是保留能力，不属于自动抓取主链路。

## 读取 follower 状态

```bash
$TOOL get-state
```

返回当前 follower 六个关节的角度/夹爪状态，可用于视觉抓取后的保守成功判定。

## OpenClaw 约束

- 不允许模型自由拼串口控制命令。
- 不允许绕过 `scripts/lerobot_skill` 直接调用 `lerobot-replay`、`lerobot-teleoperate`、`lerobot-calibrate`。
- 抓取类动作必须由 `vision-grasp-arm` 先做识别与对准，再回到本 skill 执行动作模板。

## 自然语言示例

- “检查机械臂环境是不是正常”
- “看看当前机械臂串口”
- “把 follower 的 shoulder_pan 往左微调一点”
- “回放 zhuaqu 数据集”
- “只回放活动关节”
- “读取当前夹爪状态”
