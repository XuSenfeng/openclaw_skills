#!/bin/zsh

# Optional positional arguments:
# 1) dataset name or path (default: latest dataset under ./data)
# 2) robot port (default: auto detect)
DATASET_INPUT="${1:-}"
ROBOT_PORT_INPUT="${2:-}"
MAX_RELATIVE_TARGET="${MAX_RELATIVE_TARGET:-10}"
MOVEMENT_THRESHOLD="${MOVEMENT_THRESHOLD:-2}"
ACTIVE_JOINTS="${ACTIVE_JOINTS:-}"
EPISODE_INDEX="${EPISODE_INDEX:-0}"
REPLAY_FPS="${REPLAY_FPS:-0}"
DRY_RUN="${DRY_RUN:-false}"
SKIP_DATASET_SANITY_CHECK="${SKIP_DATASET_SANITY_CHECK:-false}"
SCRIPT_PATH="${0:A}"
SCRIPT_DIR="${SCRIPT_PATH:h}"
REPO_ROOT="${SCRIPT_DIR:h}"

source "$SCRIPT_DIR/common.sh"

ROBOT_PORT="$(resolve_port_or_exit follower "$ROBOT_PORT_INPUT")" || exit 1

enter_repo_root
activate_lerobot_env
ensure_data_root

DATASET_PATH_ON_DISK="$(resolve_dataset_root_path "$DATASET_INPUT")" || {
  echo "❌ 错误：未在 $REPO_ROOT/data 下找到可回放的数据集，请先录制动作数据。"
  deactivate_lerobot_env
  exit 1
}
DATASET_NAME="$(dataset_root_path_to_name "$DATASET_PATH_ON_DISK")"
DATASET_REPO_ID="$(dataset_name_to_repo_id "$DATASET_NAME")"

if [ ! -d "$DATASET_PATH_ON_DISK" ]; then
  echo "❌ 错误：数据集目录不存在：$DATASET_PATH_ON_DISK"
  deactivate_lerobot_env
  exit 1
fi

if ! is_lerobot_dataset_dir "$DATASET_PATH_ON_DISK"; then
  echo "❌ 错误：目录不是有效的 LeRobot 数据集：$DATASET_PATH_ON_DISK"
  deactivate_lerobot_env
  exit 1
fi

if [ "$SKIP_DATASET_SANITY_CHECK" != "true" ]; then
  python "$SCRIPT_DIR/check_dataset_health.py" "$DATASET_PATH_ON_DISK"
  HEALTH_EXIT_CODE=$?
  if [ $HEALTH_EXIT_CODE -ne 0 ]; then
    echo "❌ 错误：数据集统计异常，不建议直接回放：$DATASET_PATH_ON_DISK"
    echo "ℹ️ 如确认仍要回放，可临时设置 SKIP_DATASET_SANITY_CHECK=true"
    deactivate_lerobot_env
    exit $HEALTH_EXIT_CODE
  fi
fi

echo "🚀 开始执行仅运动活动关节的回放..."
echo "📦 使用数据集标识：$DATASET_REPO_ID"
echo "📁 数据集目录：$DATASET_PATH_ON_DISK"
echo "🎬 Episode：$EPISODE_INDEX"
echo "🔌 使用 follower 端口：$ROBOT_PORT"
echo "🛡️  follower 单步限幅：$MAX_RELATIVE_TARGET"
echo "📏 自动判定活动关节阈值：$MOVEMENT_THRESHOLD"
echo "🎯 手动指定活动关节：${ACTIVE_JOINTS:-<auto>}"
echo "⏱️  回放帧率：${REPLAY_FPS:-<dataset fps>}"
echo "🧪 Dry run：$DRY_RUN"

REPLAY_ARGS=(
  --dataset-repo-id "$DATASET_REPO_ID"
  --dataset-root "$DATASET_PATH_ON_DISK"
  --episode "$EPISODE_INDEX"
  --robot-port "$ROBOT_PORT"
  --max-relative-target "$MAX_RELATIVE_TARGET"
  --movement-threshold "$MOVEMENT_THRESHOLD"
  --fps "$REPLAY_FPS"
)

if [ -n "$ACTIVE_JOINTS" ]; then
  REPLAY_ARGS+=(--active-joints "$ACTIVE_JOINTS")
fi

if [ "$DRY_RUN" = "true" ]; then
  REPLAY_ARGS+=(--dry-run)
fi

python "$SCRIPT_DIR/replay_moving_joints_only.py" "${REPLAY_ARGS[@]}"

REPLAY_EXIT_CODE=$?
if [ $REPLAY_EXIT_CODE -eq 0 ]; then
  echo "✅ 仅活动关节回放执行成功！"
else
  echo "❌ 仅活动关节回放执行失败，退出码：$REPLAY_EXIT_CODE"
fi

deactivate_lerobot_env
exit $REPLAY_EXIT_CODE
