#!/usr/bin/env python3

from __future__ import annotations

import argparse
import time

from lerobot.datasets.lerobot_dataset import LeRobotDataset
from lerobot.motors import Motor, MotorNormMode
from lerobot.motors.feetech import FeetechMotorsBus
from lerobot.utils.constants import ACTION
from lerobot.utils.robot_utils import precise_sleep


JOINTS = (
    "shoulder_pan",
    "shoulder_lift",
    "elbow_flex",
    "wrist_flex",
    "wrist_roll",
    "gripper",
)


def parse_args():
    parser = argparse.ArgumentParser(
        description="Replay only moving joints from a dataset while freezing all other joints."
    )
    parser.add_argument("--dataset-repo-id", required=True)
    parser.add_argument("--dataset-root", required=True)
    parser.add_argument("--episode", type=int, default=0)
    parser.add_argument("--robot-port", required=True)
    parser.add_argument("--robot-id", default="my_awesome_follower_arm")
    parser.add_argument("--max-relative-target", type=float, default=10.0)
    parser.add_argument("--movement-threshold", type=float, default=2.0)
    parser.add_argument("--active-joints", default="")
    parser.add_argument("--fps", type=int, default=0)
    parser.add_argument("--dry-run", action="store_true")
    return parser.parse_args()


def normalize_joint_name(name: str) -> str:
    return name if name.endswith(".pos") else f"{name}.pos"


def denormalize_joint_name(name: str) -> str:
    return name[:-4] if name.endswith(".pos") else name


def build_bus(port: str) -> FeetechMotorsBus:
    motors = {
        "shoulder_pan": Motor(1, "sts3215", MotorNormMode.DEGREES),
        "shoulder_lift": Motor(2, "sts3215", MotorNormMode.DEGREES),
        "elbow_flex": Motor(3, "sts3215", MotorNormMode.DEGREES),
        "wrist_flex": Motor(4, "sts3215", MotorNormMode.DEGREES),
        "wrist_roll": Motor(5, "sts3215", MotorNormMode.DEGREES),
        "gripper": Motor(6, "sts3215", MotorNormMode.RANGE_0_100),
    }
    return FeetechMotorsBus(port, motors)


def load_episode_actions(dataset: LeRobotDataset, episode: int):
    episode_frames = dataset.hf_dataset.filter(lambda x: x["episode_index"] == episode)
    if len(episode_frames) == 0:
        raise ValueError(f"Episode {episode} not found in dataset.")

    action_names = dataset.features[ACTION]["names"]
    rows = []
    for idx in range(len(episode_frames)):
        action_array = episode_frames[idx][ACTION]
        rows.append({name: float(action_array[i]) for i, name in enumerate(action_names)})
    return action_names, rows


def compute_joint_ranges(action_names, rows):
    ranges = {}
    for name in action_names:
        values = [row[name] for row in rows]
        ranges[name] = max(values) - min(values)
    return ranges


def resolve_active_joints(action_names, joint_ranges, active_joints_arg, movement_threshold):
    if active_joints_arg.strip():
        requested = [normalize_joint_name(name.strip()) for name in active_joints_arg.split(",") if name.strip()]
        invalid = [name for name in requested if name not in action_names]
        if invalid:
            raise ValueError(f"Unknown joints in --active-joints: {invalid}")
        return requested

    active = [name for name in action_names if joint_ranges[name] > movement_threshold]
    if not active:
        raise ValueError(
            f"No joints exceeded movement threshold {movement_threshold}. "
            "Lower the threshold or pass --active-joints explicitly."
        )
    return active


def print_joint_summary(action_names, joint_ranges, active_joints):
    print("Joint ranges in selected episode:", flush=True)
    for name in action_names:
        status = "ACTIVE" if name in active_joints else "FROZEN"
        print(f"  - {name}: range={joint_ranges[name]:.3f} [{status}]", flush=True)


def read_pose(bus: FeetechMotorsBus, joint_names: list[str]) -> dict[str, float]:
    return {name: float(bus.read("Present_Position", denormalize_joint_name(name))) for name in joint_names}


def clamp_delta(current: float, target: float, max_relative_target: float) -> float:
    if max_relative_target <= 0:
        return target
    delta = target - current
    if delta > max_relative_target:
        return current + max_relative_target
    if delta < -max_relative_target:
        return current - max_relative_target
    return target


def write_pose(bus: FeetechMotorsBus, pose: dict[str, float]) -> None:
    for name, value in pose.items():
        bus.write("Goal_Position", denormalize_joint_name(name), float(value))


def main():
    args = parse_args()

    dataset = LeRobotDataset(args.dataset_repo_id, root=args.dataset_root, episodes=[args.episode])
    action_names, rows = load_episode_actions(dataset, args.episode)
    joint_ranges = compute_joint_ranges(action_names, rows)
    active_joints = resolve_active_joints(
        action_names=action_names,
        joint_ranges=joint_ranges,
        active_joints_arg=args.active_joints,
        movement_threshold=args.movement_threshold,
    )
    frozen_joints = [name for name in action_names if name not in active_joints]

    print_joint_summary(action_names, joint_ranges, active_joints)
    print(f"Replay mode: only move {active_joints}", flush=True)
    print(f"Frozen joints: {frozen_joints}", flush=True)

    if args.dry_run:
        return

    replay_fps = args.fps if args.fps > 0 else dataset.fps
    bus = build_bus(args.robot_port)
    bus.connect(handshake=False)
    try:
        bus.calibration = bus.read_calibration()
        frozen_pose = read_pose(bus, action_names)
        print("Frozen pose captured from current follower state.", flush=True)

        for row in rows:
            start_loop_t = time.perf_counter()
            current_pose = read_pose(bus, action_names)
            replay_action = dict(frozen_pose)
            for name in active_joints:
                replay_action[name] = clamp_delta(
                    current=current_pose[name],
                    target=row[name],
                    max_relative_target=args.max_relative_target,
                )

            write_pose(bus, replay_action)

            dt_s = time.perf_counter() - start_loop_t
            precise_sleep(max(1 / replay_fps - dt_s, 0.0))
    finally:
        bus.disconnect()


if __name__ == "__main__":
    main()
