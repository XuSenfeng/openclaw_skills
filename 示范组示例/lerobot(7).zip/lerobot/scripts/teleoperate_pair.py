#!/usr/bin/env python3

from __future__ import annotations

import argparse
import json
import signal
import time

from lerobot.motors import Motor, MotorNormMode
from lerobot.motors.feetech import FeetechMotorsBus
from lerobot.utils.robot_utils import precise_sleep


JOINTS = (
    "shoulder_pan",
    "shoulder_lift",
    "elbow_flex",
    "wrist_flex",
    "wrist_roll",
    "gripper",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Sequential leader -> follower teleoperation without sync_read.")
    parser.add_argument("--follower-port", required=True)
    parser.add_argument("--leader-port", required=True)
    parser.add_argument("--fps", type=int, default=30)
    parser.add_argument("--teleop-time-s", type=float)
    parser.add_argument("--max-relative-target", type=float, default=10.0)
    return parser.parse_args()


def build_bus(port: str) -> FeetechMotorsBus:
    motors = {
        "shoulder_pan": Motor(1, "sts3215", MotorNormMode.DEGREES),
        "shoulder_lift": Motor(2, "sts3215", MotorNormMode.DEGREES),
        "elbow_flex": Motor(3, "sts3215", MotorNormMode.DEGREES),
        "wrist_flex": Motor(4, "sts3215", MotorNormMode.DEGREES),
        "wrist_roll": Motor(5, "sts3215", MotorNormMode.DEGREES),
        "gripper": Motor(6, "sts3215", MotorNormMode.RANGE_0_100),
    }
    return FeetechMotorsBus(port, motors)


def read_pose(bus: FeetechMotorsBus) -> dict[str, float]:
    return {joint: float(bus.read("Present_Position", joint)) for joint in JOINTS}


def write_pose(bus: FeetechMotorsBus, pose: dict[str, float]) -> None:
    for joint in JOINTS:
        bus.write("Goal_Position", joint, float(pose[joint]))


def clamp_delta(current: float, target: float, max_relative_target: float) -> float:
    if max_relative_target <= 0:
        return target
    delta = target - current
    if delta > max_relative_target:
        return current + max_relative_target
    if delta < -max_relative_target:
        return current - max_relative_target
    return target


def format_pose(pose: dict[str, float]) -> str:
    return ", ".join(f"{joint}={pose[joint]:.3f}" for joint in JOINTS)


def main() -> int:
    args = parse_args()
    follower_bus = build_bus(args.follower_port)
    leader_bus = build_bus(args.leader_port)

    stop_requested = False

    def handle_signal(_signum, _frame) -> None:
        nonlocal stop_requested
        stop_requested = True

    signal.signal(signal.SIGINT, handle_signal)
    signal.signal(signal.SIGTERM, handle_signal)

    follower_bus.connect(handshake=False)
    leader_bus.connect(handshake=False)

    loop_count = 0
    started = time.perf_counter()

    try:
        follower_bus.calibration = follower_bus.read_calibration()
        leader_bus.calibration = leader_bus.read_calibration()

        follower_base = read_pose(follower_bus)
        leader_base = read_pose(leader_bus)
        last_command = dict(follower_base)

        print("Teleop base captured.", flush=True)
        print(f"FOLLOWER_BASE: {format_pose(follower_base)}", flush=True)
        print(f"LEADER_BASE: {format_pose(leader_base)}", flush=True)

        while not stop_requested:
            loop_start = time.perf_counter()
            elapsed = loop_start - started
            if args.teleop_time_s is not None and elapsed >= args.teleop_time_s:
                break

            leader_pose = read_pose(leader_bus)
            target_pose: dict[str, float] = {}
            for joint in JOINTS:
                desired = follower_base[joint] + (leader_pose[joint] - leader_base[joint])
                target_pose[joint] = clamp_delta(
                    current=last_command[joint],
                    target=desired,
                    max_relative_target=args.max_relative_target,
                )

            write_pose(follower_bus, target_pose)
            last_command = target_pose
            loop_count += 1

            if loop_count == 1 or loop_count % max(args.fps, 1) == 0:
                payload = {
                    "loop": loop_count,
                    "elapsed_s": round(elapsed, 3),
                    "leader_pose": leader_pose,
                    "target_pose": target_pose,
                }
                print(json.dumps(payload, ensure_ascii=False), flush=True)

            dt_s = time.perf_counter() - loop_start
            precise_sleep(max(1 / max(args.fps, 1) - dt_s, 0.0))

        final_follower_pose = read_pose(follower_bus)
        print("Teleop finished.", flush=True)
        print(f"FINAL_FOLLOWER: {format_pose(final_follower_pose)}", flush=True)
        print(
            json.dumps(
                {
                    "success": True,
                    "loops": loop_count,
                    "elapsed_s": round(time.perf_counter() - started, 3),
                    "final_follower_pose": final_follower_pose,
                },
                ensure_ascii=False,
            ),
            flush=True,
        )
        return 0
    finally:
        leader_bus.disconnect()
        follower_bus.disconnect()


if __name__ == "__main__":
    raise SystemExit(main())
