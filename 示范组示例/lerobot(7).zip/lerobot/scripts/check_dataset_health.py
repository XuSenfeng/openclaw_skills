#!/usr/bin/env python3

import json
import math
import sys
from pathlib import Path

JOINTS = [
    "shoulder_pan",
    "shoulder_lift",
    "elbow_flex",
    "wrist_flex",
    "wrist_roll",
    "gripper",
]


def main() -> int:
    if len(sys.argv) != 2:
        print("Usage: check_dataset_health.py <dataset_root>", file=sys.stderr)
        return 1

    dataset_root = Path(sys.argv[1]).expanduser().resolve()
    stats_path = dataset_root / "meta" / "stats.json"
    if not stats_path.is_file():
        print(f"Missing stats.json: {stats_path}", file=sys.stderr)
        return 1

    stats = json.loads(stats_path.read_text())
    action_mins = stats["action"]["min"]
    action_maxes = stats["action"]["max"]
    obs_mins = stats["observation.state"]["min"]
    obs_maxes = stats["observation.state"]["max"]

    problems: list[str] = []
    for i, joint in enumerate(JOINTS):
        action_range = float(action_maxes[i]) - float(action_mins[i])
        obs_range = float(obs_maxes[i]) - float(obs_mins[i])
        ratio = math.inf if obs_range == 0 else action_range / obs_range

        if action_range > 5 and obs_range <= 0.5:
            problems.append(
                f"{joint}: action_range={action_range:.3f}, observation_range={obs_range:.3f}"
            )
        elif obs_range > 0 and ratio > 50:
            problems.append(
                f"{joint}: action/observation ratio too large ({ratio:.2f})"
            )

    if problems:
        print("Dataset stats look suspicious for replay:")
        for problem in problems:
            print(f"- {problem}")
        return 2

    print("Dataset stats look reasonable for replay.")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
