#!/usr/bin/env python3

from __future__ import annotations

import argparse
import glob
import json
from pathlib import Path


PREFERRED_KEYWORDS = (
    "usbmodem",
    "usbserial",
    "wchusbserial",
    "ttyusb",
    "ttyacm",
    "cu.usb",
    "tty.usb",
    "silabs",
)
IGNORED_KEYWORDS = (
    "bluetooth",
    "incoming-port",
    "miniboom",
    "airpods",
    "iqoo",
)


def _score_port(path: str) -> tuple[int, str]:
    lower = path.lower()
    score = 0
    for keyword in PREFERRED_KEYWORDS:
        if keyword in lower:
            score += 10
    if "/dev/cu." in lower:
        score += 2
    if "/dev/tty." in lower:
        score += 1
    return score, lower


def list_ports() -> list[dict[str, object]]:
    patterns = (
        "/dev/cu.*",
        "/dev/tty.*",
        "/dev/ttyUSB*",
        "/dev/ttyACM*",
    )
    seen: set[str] = set()
    raw_paths: list[str] = []
    for pattern in patterns:
        for matched in glob.glob(pattern):
            if matched in seen:
                continue
            seen.add(matched)
            raw_paths.append(matched)

    entries: list[dict[str, object]] = []
    for path in raw_paths:
        lower = path.lower()
        if any(keyword in lower for keyword in IGNORED_KEYWORDS):
            continue
        score, _ = _score_port(path)
        entries.append(
            {
                "path": path,
                "basename": Path(path).name,
                "score": score,
                "preferred": score >= 10,
            }
        )

    entries.sort(key=lambda item: (-int(item["score"]), str(item["path"])))
    return entries


def suggested_ports(entries: list[dict[str, object]]) -> dict[str, str | None]:
    ordered = [str(item["path"]) for item in entries]
    return {
        "follower": ordered[0] if len(ordered) >= 1 else None,
        "leader": ordered[1] if len(ordered) >= 2 else None,
    }


def cmd_list(args: argparse.Namespace) -> int:
    entries = list_ports()
    payload = {
        "ports": entries,
        "suggested": suggested_ports(entries),
    }

    if args.json:
        print(json.dumps(payload, ensure_ascii=False, indent=2))
        return 0

    for entry in entries:
        print(entry["path"])
    return 0


def cmd_resolve(args: argparse.Namespace) -> int:
    entries = list_ports()
    resolved = suggested_ports(entries).get(args.role)
    if not resolved:
        return 1
    print(resolved)
    return 0


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Discover likely LeRobot serial ports.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    p_list = subparsers.add_parser("list", help="List visible serial ports.")
    p_list.add_argument("--json", action="store_true", help="Emit JSON instead of plain text.")
    p_list.set_defaults(func=cmd_list)

    p_resolve = subparsers.add_parser("resolve", help="Resolve the suggested port for a role.")
    p_resolve.add_argument("--role", choices=("follower", "leader"), required=True)
    p_resolve.set_defaults(func=cmd_resolve)

    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
