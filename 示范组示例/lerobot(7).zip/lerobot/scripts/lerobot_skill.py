#!/usr/bin/env python3

from __future__ import annotations

import argparse
import json
import os
import shutil
import subprocess
import sys
from pathlib import Path
from typing import Any


SCRIPT_DIR = Path(__file__).resolve().parent
SKILL_ROOT = SCRIPT_DIR.parent
PORT_UTILS = SCRIPT_DIR / "port_utils.py"


def candidate_conda_executables() -> list[str]:
    candidates = [
        shutil.which("mamba"),
        shutil.which("conda"),
        str(Path.home() / "miniconda3" / "bin" / "conda"),
        str(Path.home() / "anaconda3" / "bin" / "conda"),
        str(Path.home() / "miniforge3" / "bin" / "conda"),
    ]
    unique: list[str] = []
    for candidate in candidates:
        if not candidate:
            continue
        if candidate in unique:
            continue
        if Path(candidate).exists():
            unique.append(candidate)
    return unique


def json_dump(payload: dict[str, Any], exit_code: int) -> int:
    payload.setdefault("success", exit_code == 0)
    payload.setdefault("exit_code", exit_code)
    print(json.dumps(payload, ensure_ascii=False, indent=2))
    return exit_code


def run_script(script_name: str, args: list[str], env_overrides: dict[str, str] | None = None) -> subprocess.CompletedProcess[str]:
    env = os.environ.copy()
    if env_overrides:
        env.update({key: value for key, value in env_overrides.items() if value is not None})
    command = ["/bin/zsh", str(SCRIPT_DIR / script_name), *args]
    return subprocess.run(command, capture_output=True, text=True, env=env)


def detect_env_manager() -> str | None:
    for candidate in candidate_conda_executables():
        if candidate.endswith("/mamba") or Path(candidate).name == "mamba":
            return candidate
    for candidate in candidate_conda_executables():
        if candidate.endswith("/conda") or Path(candidate).name == "conda":
            return candidate
    return None


def run_manager(manager: str, args: list[str]) -> subprocess.CompletedProcess[str]:
    return subprocess.run([manager, *args], capture_output=True, text=True)


def parse_env_list(output: str) -> list[str]:
    envs: list[str] = []
    for raw_line in output.splitlines():
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        if " " in line:
            envs.append(line.split()[0])
        else:
            envs.append(line)
    return envs


def visible_ports() -> dict[str, Any]:
    result = subprocess.run(
        [sys.executable, str(PORT_UTILS), "list", "--json"],
        capture_output=True,
        text=True,
    )
    if result.returncode != 0:
        return {"ports": [], "suggested": {}}
    try:
        return json.loads(result.stdout)
    except json.JSONDecodeError:
        return {"ports": [], "suggested": {}}


def cmd_env_check(_: argparse.Namespace) -> int:
    manager = detect_env_manager()
    ports_payload = visible_ports()
    issues: list[str] = []

    if manager is None:
        issues.append("missing_conda_or_mamba")
        return json_dump(
            {
                "status": "fail",
                "issues": issues,
                "env_manager": None,
                "visible_ports": ports_payload,
            },
            1,
        )

    envs_result = run_manager(manager, ["env", "list"])
    env_names = parse_env_list(envs_result.stdout) if envs_result.returncode == 0 else []
    has_lerobot_env = "lerobot" in env_names
    if not has_lerobot_env:
        issues.append("missing_lerobot_env")

    imports_result = None
    deps_ok = False
    if has_lerobot_env:
        imports_result = run_manager(
            manager,
            [
                "run",
                "-n",
                "lerobot",
                "python",
                "-c",
                (
                    "import importlib.util, json; "
                    "mods=['lerobot','serial']; "
                    "status={m: importlib.util.find_spec(m) is not None for m in mods}; "
                    "print(json.dumps(status))"
                ),
            ],
        )
        if imports_result.returncode == 0:
            try:
                deps = json.loads(imports_result.stdout.strip() or "{}")
            except json.JSONDecodeError:
                deps = {}
            deps_ok = all(bool(value) for value in deps.values()) and bool(deps)
        if not deps_ok:
            issues.append("missing_python_dependencies")

    if not ports_payload.get("ports"):
        issues.append("no_visible_robot_ports")

    exit_code = 0 if not issues else 1
    return json_dump(
        {
            "status": "ok" if exit_code == 0 else "fail",
            "env_manager": manager,
            "has_lerobot_env": has_lerobot_env,
            "python_dependencies_ok": deps_ok,
            "visible_ports": ports_payload,
            "issues": issues,
            "raw": {
                "env_list_stdout": envs_result.stdout,
                "env_list_stderr": envs_result.stderr,
                "import_check_stdout": None if imports_result is None else imports_result.stdout,
                "import_check_stderr": None if imports_result is None else imports_result.stderr,
            },
        },
        exit_code,
    )


def cmd_find_port(_: argparse.Namespace) -> int:
    payload = visible_ports()
    return json_dump(payload, 0)


def _env_from_args(args: argparse.Namespace, include_follower: bool = False, include_leader: bool = False) -> dict[str, str]:
    env: dict[str, str] = {}
    if include_follower and getattr(args, "follower_port", None):
        env["LEROBOT_FOLLOWER_PORT"] = args.follower_port
    if include_leader and getattr(args, "leader_port", None):
        env["LEROBOT_LEADER_PORT"] = args.leader_port
    return env


def _command_payload(result: subprocess.CompletedProcess[str], extra: dict[str, Any] | None = None) -> dict[str, Any]:
    payload: dict[str, Any] = {
        "stdout": result.stdout,
        "stderr": result.stderr,
    }
    if extra:
        payload.update(extra)
    return payload


def _parse_last_json_object(text: str) -> dict[str, Any] | None:
    lines = [line.strip() for line in text.splitlines() if line.strip()]
    for line in reversed(lines):
        if not line.startswith("{"):
            continue
        try:
            return json.loads(line)
        except json.JSONDecodeError:
            continue
    return None


def cmd_calibrate(args: argparse.Namespace) -> int:
    if args.skip_leader:
        payload = {
            "success": False,
            "error": "skip_leader_not_supported_by_current_calibrate_script",
            "hint": "当前校准脚本会依次校准 follower 和 leader，请同时接入两个机械臂，或后续再拆成单臂校准。",
        }
        return json_dump(payload, 1)

    result = run_script(
        "calibrate_action.sh",
        [args.follower_port or "", args.leader_port or ""],
        _env_from_args(args, include_follower=True, include_leader=True),
    )
    return json_dump(_command_payload(result), result.returncode)


def cmd_move_joint(args: argparse.Namespace) -> int:
    env = _env_from_args(args, include_follower=True)
    env.update(
        {
            "MAX_RELATIVE_TARGET": str(args.max_relative_target),
            "HOLD_TIME_S": str(args.hold_time_s),
            "RETURN_TO_START": "true" if args.return_to_start else "false",
        }
    )
    result = run_script(
        "move_follower_joint.sh",
        [args.joint, str(args.value), args.mode, args.follower_port or ""],
        env,
    )
    return json_dump(_command_payload(result), result.returncode)


def cmd_replay_template(args: argparse.Namespace) -> int:
    env = _env_from_args(args, include_follower=True)
    env.update(
        {
            "MAX_RELATIVE_TARGET": str(args.max_relative_target),
            "EPISODE_INDEX": str(args.episode),
            "REPLAY_FPS": str(args.fps),
            "SKIP_DATASET_SANITY_CHECK": "true" if args.skip_dataset_sanity_check else "false",
        }
    )
    if args.moving_joints_only:
        env["MOVEMENT_THRESHOLD"] = str(args.movement_threshold)
        if args.active_joints:
            env["ACTIVE_JOINTS"] = args.active_joints
        if args.dry_run:
            env["DRY_RUN"] = "true"
        result = run_script(
            "play_moving_joints_only.sh",
            [args.dataset, args.follower_port or ""],
            env,
        )
    else:
        result = run_script(
            "play_action.sh",
            [args.dataset, args.follower_port or ""],
            env,
        )
    return json_dump(_command_payload(result), result.returncode)


def cmd_replay_moving_joints(args: argparse.Namespace) -> int:
    env = _env_from_args(args, include_follower=True)
    env.update(
        {
            "MAX_RELATIVE_TARGET": str(args.max_relative_target),
            "MOVEMENT_THRESHOLD": str(args.movement_threshold),
            "EPISODE_INDEX": str(args.episode),
            "REPLAY_FPS": str(args.fps),
            "DRY_RUN": "true" if args.dry_run else "false",
            "SKIP_DATASET_SANITY_CHECK": "true" if args.skip_dataset_sanity_check else "false",
        }
    )
    if args.active_joints:
        env["ACTIVE_JOINTS"] = args.active_joints
    result = run_script(
        "play_moving_joints_only.sh",
        [args.dataset, args.follower_port or ""],
        env,
    )
    return json_dump(_command_payload(result), result.returncode)


def cmd_replay_sequence(args: argparse.Namespace) -> int:
    env = _env_from_args(args, include_follower=True)
    env.update(
        {
            "ZHUAQU_DATASET": args.approach_dataset,
            "DAO_DATASET": args.place_dataset,
            "MAX_RELATIVE_TARGET": str(args.max_relative_target),
            "MOVEMENT_THRESHOLD": str(args.movement_threshold),
            "EPISODE_INDEX": str(args.episode),
            "REPLAY_FPS": str(args.fps),
            "DRY_RUN": "true" if args.dry_run else "false",
            "SKIP_DATASET_SANITY_CHECK": "true" if args.skip_dataset_sanity_check else "false",
        }
    )
    result = run_script(
        "play_zhuaqu_then_dao.sh",
        [args.follower_port or ""],
        env,
    )
    return json_dump(_command_payload(result), result.returncode)


def cmd_teleoperate(args: argparse.Namespace) -> int:
    env = _env_from_args(args, include_follower=True, include_leader=True)
    env.update(
        {
            "MAX_RELATIVE_TARGET": str(args.max_relative_target),
            "TELEOP_FPS": str(args.fps),
        }
    )
    if args.teleop_time_s is not None:
        env["TELEOP_TIME_S"] = str(args.teleop_time_s)
    result = run_script(
        "teleoperate_action.sh",
        [args.follower_port or "", args.leader_port or ""],
        env,
    )
    return json_dump(_command_payload(result), result.returncode)


def cmd_get_state(args: argparse.Namespace) -> int:
    env = _env_from_args(args, include_follower=True)
    env["MAX_RELATIVE_TARGET"] = str(args.max_relative_target)
    result = run_script("get_follower_state.sh", [args.follower_port or ""], env)
    payload = _command_payload(result)
    if result.returncode == 0:
        payload["joint_positions"] = _parse_last_json_object(result.stdout)
    return json_dump(payload, result.returncode)


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Unified OpenClaw launcher for the lerobot skill.")
    subparsers = parser.add_subparsers(dest="command", required=True)

    p_env = subparsers.add_parser("env-check", help="Check environment and visible robot ports.")
    p_env.set_defaults(func=cmd_env_check)

    p_find = subparsers.add_parser("find-port", help="List visible serial ports and role suggestions.")
    p_find.set_defaults(func=cmd_find_port)

    p_calibrate = subparsers.add_parser("calibrate", help="Calibrate follower and leader arms.")
    p_calibrate.add_argument("--follower-port")
    p_calibrate.add_argument("--leader-port")
    p_calibrate.add_argument("--skip-leader", action="store_true")
    p_calibrate.set_defaults(func=cmd_calibrate)

    p_move = subparsers.add_parser("move-joint", help="Move one follower joint.")
    p_move.add_argument("--joint", required=True)
    p_move.add_argument("--value", required=True, type=float)
    p_move.add_argument("--mode", choices=("delta", "target"), default="delta")
    p_move.add_argument("--follower-port")
    p_move.add_argument("--max-relative-target", type=float, default=5.0)
    p_move.add_argument("--hold-time-s", type=float, default=1.0)
    p_move.add_argument("--return-to-start", action="store_true")
    p_move.set_defaults(func=cmd_move_joint)

    p_replay = subparsers.add_parser("replay-template", help="Replay a recorded dataset.")
    p_replay.add_argument("--dataset", required=True)
    p_replay.add_argument("--follower-port")
    p_replay.add_argument("--episode", type=int, default=0)
    p_replay.add_argument("--fps", type=int, default=0)
    p_replay.add_argument("--max-relative-target", type=float, default=10.0)
    p_replay.add_argument("--moving-joints-only", action="store_true")
    p_replay.add_argument("--movement-threshold", type=float, default=2.0)
    p_replay.add_argument("--active-joints", default="")
    p_replay.add_argument("--dry-run", action="store_true")
    p_replay.add_argument("--skip-dataset-sanity-check", action="store_true")
    p_replay.set_defaults(func=cmd_replay_template)

    p_replay_moving = subparsers.add_parser("replay-moving-joints", help="Replay only active joints from a dataset.")
    p_replay_moving.add_argument("--dataset", required=True)
    p_replay_moving.add_argument("--follower-port")
    p_replay_moving.add_argument("--episode", type=int, default=0)
    p_replay_moving.add_argument("--fps", type=int, default=0)
    p_replay_moving.add_argument("--max-relative-target", type=float, default=10.0)
    p_replay_moving.add_argument("--movement-threshold", type=float, default=2.0)
    p_replay_moving.add_argument("--active-joints", default="")
    p_replay_moving.add_argument("--dry-run", action="store_true")
    p_replay_moving.add_argument("--skip-dataset-sanity-check", action="store_true")
    p_replay_moving.set_defaults(func=cmd_replay_moving_joints)

    p_seq = subparsers.add_parser("replay-sequence", help="Replay the fixed zhuaqu -> dao sequence.")
    p_seq.add_argument("--follower-port")
    p_seq.add_argument("--approach-dataset", default="zhuaqu")
    p_seq.add_argument("--place-dataset", default="dao")
    p_seq.add_argument("--episode", type=int, default=0)
    p_seq.add_argument("--fps", type=int, default=0)
    p_seq.add_argument("--max-relative-target", type=float, default=10.0)
    p_seq.add_argument("--movement-threshold", type=float, default=2.0)
    p_seq.add_argument("--dry-run", action="store_true")
    p_seq.add_argument("--skip-dataset-sanity-check", action="store_true")
    p_seq.set_defaults(func=cmd_replay_sequence)

    p_teleop = subparsers.add_parser("teleoperate", help="Run leader -> follower teleoperation.")
    p_teleop.add_argument("--follower-port")
    p_teleop.add_argument("--leader-port")
    p_teleop.add_argument("--fps", type=int, default=30)
    p_teleop.add_argument("--teleop-time-s", type=float)
    p_teleop.add_argument("--max-relative-target", type=float, default=10.0)
    p_teleop.set_defaults(func=cmd_teleoperate)

    p_state = subparsers.add_parser("get-state", help="Read current follower joint positions.")
    p_state.add_argument("--follower-port")
    p_state.add_argument("--max-relative-target", type=float, default=10.0)
    p_state.set_defaults(func=cmd_get_state)

    return parser


def main() -> int:
    parser = build_parser()
    args = parser.parse_args()
    return args.func(args)


if __name__ == "__main__":
    raise SystemExit(main())
