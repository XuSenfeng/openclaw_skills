#!/usr/bin/env python3

import sys
import threading

import lerobot.scripts.lerobot_record as lerobot_record
import lerobot.utils.control_utils as control_utils


class StdinListener:
    def __init__(self, target):
        self._thread = threading.Thread(target=target, daemon=True)
        self._thread.start()

    def stop(self):
        # The reader thread blocks on stdin.readline(); a no-op stop keeps
        # compatibility with LeRobot's keyboard listener cleanup path.
        return None


def init_stdin_listener():
    events = {
        "exit_early": False,
        "rerecord_episode": False,
        "stop_recording": False,
    }

    if not sys.stdin.isatty():
        print("WARNING: stdin is not a TTY. Pressing Enter to stop recording will not be available.", flush=True)
        return None, events

    def wait_for_commands():
        print("⌨️  录制开始后，直接按 Enter 即可停止并保存当前 episode。", flush=True)
        print("⌨️  输入 r 再回车可丢弃当前 episode 并重新录制。", flush=True)

        while True:
            line = sys.stdin.readline()
            if line == "":
                break

            command = line.strip().lower()
            if command == "":
                print("⏹️  收到 Enter，准备停止录制并保存当前 episode...", flush=True)
                events["stop_recording"] = True
                events["exit_early"] = True
                break

            if command == "r":
                print("🔁 收到 r，准备丢弃当前 episode 并重新录制...", flush=True)
                events["rerecord_episode"] = True
                events["exit_early"] = True
                continue

            print("ℹ️  未识别输入。直接按 Enter 停止；输入 r 再回车重录。", flush=True)

    listener = StdinListener(wait_for_commands)
    return listener, events


def main():
    control_utils.init_keyboard_listener = init_stdin_listener
    lerobot_record.init_keyboard_listener = init_stdin_listener
    lerobot_record.main()


if __name__ == "__main__":
    main()
