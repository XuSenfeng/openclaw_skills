#!/usr/bin/env python3

from __future__ import annotations

import argparse
import json

from lerobot.motors import Motor, MotorNormMode
from lerobot.motors.feetech import FeetechMotorsBus


JOINTS = (
    "shoulder_pan",
    "shoulder_lift",
    "elbow_flex",
    "wrist_flex",
    "wrist_roll",
    "gripper",
)


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Read current follower joint positions.")
    parser.add_argument("--port", required=True)
    parser.add_argument("--robot-id", default="my_awesome_follower_arm")
    parser.add_argument("--max-relative-target", type=float, default=10.0)
    return parser.parse_args()


def build_bus(port: str) -> FeetechMotorsBus:
    motors = {
        "shoulder_pan": Motor(1, "sts3215", MotorNormMode.DEGREES),
        "shoulder_lift": Motor(2, "sts3215", MotorNormMode.DEGREES),
        "elbow_flex": Motor(3, "sts3215", MotorNormMode.DEGREES),
        "wrist_flex": Motor(4, "sts3215", MotorNormMode.DEGREES),
        "wrist_roll": Motor(5, "sts3215", MotorNormMode.DEGREES),
        "gripper": Motor(6, "sts3215", MotorNormMode.RANGE_0_100),
    }
    return FeetechMotorsBus(port, motors)


def main() -> int:
    args = parse_args()
    bus = build_bus(args.port)
    bus.connect(handshake=False)
    try:
        bus.calibration = bus.read_calibration()
        payload = {joint: float(bus.read("Present_Position", joint)) for joint in JOINTS}
        print(json.dumps(payload, ensure_ascii=False, sort_keys=True))
    finally:
        bus.disconnect()

    return 0


if __name__ == "__main__":
    raise SystemExit(main())
