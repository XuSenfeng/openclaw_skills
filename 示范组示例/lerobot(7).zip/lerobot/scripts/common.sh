#!/bin/zsh

enter_repo_root() {
  echo "🔍 切换到 lerobot 目录：$REPO_ROOT"
  cd "$REPO_ROOT" || {
    echo "❌ 错误：无法切换到目录 $REPO_ROOT，请检查脚本所在路径是否正确！"
    exit 1
  }
}

activate_lerobot_env() {
  if command -v mamba >/dev/null 2>&1; then
    local mamba_hook
    mamba_hook="$(mamba shell hook --shell zsh 2>/dev/null)" || {
      echo "❌ 错误：无法初始化 mamba shell hook！"
      exit 1
    }

    eval "$mamba_hook"
    echo "🔧 激活 lerobot Mamba 环境..."
    mamba activate lerobot || {
      echo "❌ 错误：无法激活 lerobot 环境！请执行 mamba env list 检查环境是否存在。"
      exit 1
    }

    ACTIVE_ENV_TOOL="mamba"
    return 0
  fi

  local fallback_conda=""
  if [ -x "$HOME/miniconda3/bin/conda" ]; then
    fallback_conda="$HOME/miniconda3/bin/conda"
  elif [ -x "$HOME/anaconda3/bin/conda" ]; then
    fallback_conda="$HOME/anaconda3/bin/conda"
  elif [ -x "$HOME/miniforge3/bin/conda" ]; then
    fallback_conda="$HOME/miniforge3/bin/conda"
  fi

  if [ -n "$fallback_conda" ]; then
    local conda_base="${fallback_conda:h:h}"
    if [ -f "$conda_base/etc/profile.d/conda.sh" ]; then
      source "$conda_base/etc/profile.d/conda.sh"
      echo "🔧 激活 lerobot Conda 环境..."
      conda activate lerobot || {
        echo "❌ 错误：无法激活 lerobot 环境！请执行 $fallback_conda env list 检查环境是否存在。"
        exit 1
      }

      ACTIVE_ENV_TOOL="conda"
      return 0
    fi
  fi

  if command -v conda >/dev/null 2>&1; then
    local conda_base
    conda_base="$(conda info --base 2>/dev/null)"
    if [ -z "$conda_base" ] || [ ! -f "$conda_base/etc/profile.d/conda.sh" ]; then
      echo "❌ 错误：未找到 Conda 配置，请先初始化 Conda 或 Mamba。"
      exit 1
    fi

    source "$conda_base/etc/profile.d/conda.sh"
    echo "🔧 激活 lerobot Conda 环境..."
    conda activate lerobot || {
      echo "❌ 错误：无法激活 lerobot 环境！请执行 conda env list 检查环境是否存在。"
      exit 1
    }

    ACTIVE_ENV_TOOL="conda"
    return 0
  fi

  echo "❌ 错误：未找到 mamba 或 conda，请先安装并初始化环境管理器。"
  exit 1
}

deactivate_lerobot_env() {
  if [ "${ACTIVE_ENV_TOOL:-}" = "mamba" ]; then
    mamba deactivate >/dev/null 2>&1 || conda deactivate >/dev/null 2>&1 || true
    return 0
  fi

  if [ "${ACTIVE_ENV_TOOL:-}" = "conda" ]; then
    conda deactivate >/dev/null 2>&1 || true
  fi
}

ensure_data_root() {
  DATA_ROOT="$REPO_ROOT/data"

  if [ ! -d "$DATA_ROOT" ]; then
    mkdir -p "$DATA_ROOT" || {
      echo "❌ 错误：无法创建数据目录 $DATA_ROOT"
      exit 1
    }
    echo "📁 已创建数据目录：$DATA_ROOT"
  fi
}

role_env_var_name() {
  case "$1" in
    follower) printf "%s\n" "LEROBOT_FOLLOWER_PORT" ;;
    leader) printf "%s\n" "LEROBOT_LEADER_PORT" ;;
    *)
      echo "❌ 错误：未知机械臂角色：$1" >&2
      return 1
      ;;
  esac
}

resolve_port_or_exit() {
  local role="$1"
  local explicit_port="$2"
  local env_var_name
  local env_port
  local resolved_port

  env_var_name="$(role_env_var_name "$role")" || return 1
  env_port="${(P)env_var_name:-}"

  if [ -n "$explicit_port" ]; then
    printf "%s\n" "$explicit_port"
    return 0
  fi

  if [ -n "$env_port" ]; then
    printf "%s\n" "$env_port"
    return 0
  fi

  resolved_port="$(python3 "$SCRIPT_DIR/port_utils.py" resolve --role "$role" 2>/dev/null)" || true
  if [ -n "$resolved_port" ]; then
    printf "%s\n" "$resolved_port"
    return 0
  fi

  echo "❌ 错误：未能自动发现 ${role} 机械臂串口。" >&2
  echo "ℹ️ 请显式传入端口，或设置环境变量 ${env_var_name}。" >&2
  echo "ℹ️ 可先运行：python3 $SCRIPT_DIR/port_utils.py list --json" >&2
  return 1
}

is_lerobot_dataset_dir() {
  local dir="$1"
  [ -f "$dir/meta/info.json" ] && find "$dir/data" -type f -name '*.parquet' -print -quit 2>/dev/null | grep -q .
}

next_dataset_name() {
  local prefix="$1"
  local max_index=0
  local dir
  local name
  local suffix
  local index

  ensure_data_root

  while IFS= read -r dir; do
    name="${dir##*/}"
    suffix="${name#${prefix}_}"
    if [[ "$suffix" =~ ^[0-9]+$ ]]; then
      index=$((10#$suffix))
      if [ "$index" -gt "$max_index" ]; then
        max_index="$index"
      fi
    fi
  done < <(find "$DATA_ROOT" -mindepth 1 -maxdepth 1 -type d -name "${prefix}_*")

  printf "%s_%03d\n" "$prefix" $((max_index + 1))
}

latest_dataset_name() {
  local latest_name=""
  local dir
  local name

  ensure_data_root

  while IFS= read -r dir; do
    if ! is_lerobot_dataset_dir "$dir"; then
      continue
    fi

    name="${dir##*/}"
    if [ -z "$latest_name" ] || [[ "$name" > "$latest_name" ]]; then
      latest_name="$name"
    fi
  done < <(find "$DATA_ROOT" -mindepth 1 -maxdepth 1 -type d)

  if [ -z "$latest_name" ]; then
    return 1
  fi

  printf "%s\n" "$latest_name"
}

dataset_name_to_repo_id() {
  local dataset_name="$1"
  printf "local/%s\n" "$dataset_name"
}

dataset_root_path_to_name() {
  local dataset_root="$1"
  printf "%s\n" "${dataset_root:t}"
}

resolve_dataset_root_path() {
  local dataset_input="$1"
  local dataset_name

  if [ -z "$dataset_input" ]; then
    dataset_name="$(latest_dataset_name)" || return 1
    printf "%s/%s\n" "$DATA_ROOT" "$dataset_name"
    return $?
  fi

  case "$dataset_input" in
    /*|./*|../*|data/*)
      printf "%s\n" "${dataset_input:A}"
      ;;
    *)
      printf "%s/%s\n" "$DATA_ROOT" "$dataset_input"
      ;;
  esac
}
