#!/bin/zsh

# Optional positional arguments:
# 1) follower robot port (default: auto detect)
ROBOT_PORT_INPUT="${1:-}"
ZHUAQU_DATASET="${ZHUAQU_DATASET:-zhuaqu}"
DAO_DATASET="${DAO_DATASET:-dao}"
MAX_RELATIVE_TARGET="${MAX_RELATIVE_TARGET:-10}"
MOVEMENT_THRESHOLD="${MOVEMENT_THRESHOLD:-2}"
ZHUAQU_MOVEMENT_THRESHOLD="${ZHUAQU_MOVEMENT_THRESHOLD:-$MOVEMENT_THRESHOLD}"
DAO_MOVEMENT_THRESHOLD="${DAO_MOVEMENT_THRESHOLD:-$MOVEMENT_THRESHOLD}"
ZHUAQU_ACTIVE_JOINTS="${ZHUAQU_ACTIVE_JOINTS:-}"
DAO_ACTIVE_JOINTS="${DAO_ACTIVE_JOINTS:-}"
EPISODE_INDEX="${EPISODE_INDEX:-0}"
REPLAY_FPS="${REPLAY_FPS:-0}"
DRY_RUN="${DRY_RUN:-false}"
SKIP_DATASET_SANITY_CHECK="${SKIP_DATASET_SANITY_CHECK:-false}"
SCRIPT_PATH="${0:A}"
SCRIPT_DIR="${SCRIPT_PATH:h}"

source "$SCRIPT_DIR/common.sh"

ROBOT_PORT="$(resolve_port_or_exit follower "$ROBOT_PORT_INPUT")" || exit 1

run_stage() {
  local stage_name="$1"
  local dataset_name="$2"
  local threshold="$3"
  local active_joints="$4"

  echo "=============================="
  echo "▶️  开始回放阶段：$stage_name"
  echo "📦 数据集：$dataset_name"
  echo "📏 活动关节阈值：$threshold"
  echo "🎯 活动关节：${active_joints:-<auto>}"
  echo "=============================="

  MAX_RELATIVE_TARGET="$MAX_RELATIVE_TARGET" \
  MOVEMENT_THRESHOLD="$threshold" \
  ACTIVE_JOINTS="$active_joints" \
  EPISODE_INDEX="$EPISODE_INDEX" \
  REPLAY_FPS="$REPLAY_FPS" \
  DRY_RUN="$DRY_RUN" \
  SKIP_DATASET_SANITY_CHECK="$SKIP_DATASET_SANITY_CHECK" \
  "$SCRIPT_DIR/play_moving_joints_only.sh" "$dataset_name" "$ROBOT_PORT"
}

run_stage "zhuaqu" "$ZHUAQU_DATASET" "$ZHUAQU_MOVEMENT_THRESHOLD" "$ZHUAQU_ACTIVE_JOINTS"
ZHUAQU_EXIT_CODE=$?
if [ $ZHUAQU_EXIT_CODE -ne 0 ]; then
  echo "❌ zhuaqu 阶段失败，已停止后续 dao 回放。"
  exit $ZHUAQU_EXIT_CODE
fi

run_stage "dao" "$DAO_DATASET" "$DAO_MOVEMENT_THRESHOLD" "$DAO_ACTIVE_JOINTS"
DAO_EXIT_CODE=$?
if [ $DAO_EXIT_CODE -ne 0 ]; then
  echo "❌ dao 阶段失败。"
  exit $DAO_EXIT_CODE
fi

echo "✅ 已按顺序完成 zhuaqu -> dao 回放。"
