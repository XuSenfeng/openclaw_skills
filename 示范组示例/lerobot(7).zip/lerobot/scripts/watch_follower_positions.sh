#!/bin/zsh

# Optional positional arguments:
# 1) follower robot port (default: auto detect)
ROBOT_PORT_INPUT="${1:-}"
SCRIPT_PATH="${0:A}"
SCRIPT_DIR="${SCRIPT_PATH:h}"
REPO_ROOT="${SCRIPT_DIR:h}"

source "$SCRIPT_DIR/common.sh"

ROBOT_PORT="$(resolve_port_or_exit follower "$ROBOT_PORT_INPUT")" || exit 1

enter_repo_root
activate_lerobot_env

python - <<PY
from lerobot.motors import Motor, MotorNormMode
from lerobot.motors.feetech import FeetechMotorsBus

port = "${ROBOT_PORT}"
bus = FeetechMotorsBus(
    port=port,
    motors={
        "shoulder_pan": Motor(1, "sts3215", MotorNormMode.DEGREES),
        "shoulder_lift": Motor(2, "sts3215", MotorNormMode.DEGREES),
        "elbow_flex": Motor(3, "sts3215", MotorNormMode.DEGREES),
        "wrist_flex": Motor(4, "sts3215", MotorNormMode.DEGREES),
        "wrist_roll": Motor(5, "sts3215", MotorNormMode.DEGREES),
        "gripper": Motor(6, "sts3215", MotorNormMode.RANGE_0_100),
    },
)

print(f"Watching follower positions on {port}")
print("Move the follower joints by hand. Press Ctrl+C to stop.")

try:
    bus.connect(handshake=False)
    while True:
        positions = bus.sync_read("Present_Position", normalize=False)
        print(
            "\r"
            f"pan={positions['shoulder_pan']:4d}  "
            f"lift={positions['shoulder_lift']:4d}  "
            f"elbow={positions['elbow_flex']:4d}  "
            f"wflex={positions['wrist_flex']:4d}  "
            f"wroll={positions['wrist_roll']:4d}  "
            f"grip={positions['gripper']:4d}",
            end="",
            flush=True,
        )
except KeyboardInterrupt:
    print("\nStopped.")
finally:
    try:
        bus.disconnect()
    except Exception:
        pass
PY

WATCH_EXIT_CODE=$?
deactivate_lerobot_env
exit $WATCH_EXIT_CODE
