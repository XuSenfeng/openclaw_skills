#!/bin/zsh

# Optional positional arguments:
# 1) joint name (default: shoulder_pan)
# 2) value (default: 5)
# 3) mode: delta|target (default: delta)
# 4) follower robot port (default: auto detect)
JOINT_NAME="${1:-shoulder_pan}"
JOINT_VALUE="${2:-5}"
MOVE_MODE="${3:-delta}"
ROBOT_PORT_INPUT="${4:-}"
MAX_RELATIVE_TARGET="${MAX_RELATIVE_TARGET:-5}"
HOLD_TIME_S="${HOLD_TIME_S:-1}"
RETURN_TO_START="${RETURN_TO_START:-false}"
SCRIPT_PATH="${0:A}"
SCRIPT_DIR="${SCRIPT_PATH:h}"
REPO_ROOT="${SCRIPT_DIR:h}"

source "$SCRIPT_DIR/common.sh"

ROBOT_PORT="$(resolve_port_or_exit follower "$ROBOT_PORT_INPUT")" || exit 1

enter_repo_root
activate_lerobot_env

echo "🚀 开始直接控制 follower 单个关节..."
echo "🔌 follower 端口：$ROBOT_PORT"
echo "🦾 目标关节：$JOINT_NAME"
echo "🎯 控制模式：$MOVE_MODE"
echo "🔢 输入数值：$JOINT_VALUE"
echo "🛡️  单步限幅：$MAX_RELATIVE_TARGET"
echo "⏱️  保持时长：$HOLD_TIME_S 秒"
echo "↩️  执行后回到起始位：$RETURN_TO_START"

MOVE_ARGS=(
  --joint "$JOINT_NAME"
  --value "$JOINT_VALUE"
  --mode "$MOVE_MODE"
  --port "$ROBOT_PORT"
  --max-relative-target "$MAX_RELATIVE_TARGET"
  --hold-time-s "$HOLD_TIME_S"
)

if [ "$RETURN_TO_START" = "true" ]; then
  MOVE_ARGS+=(--return-to-start)
fi

python "$SCRIPT_DIR/move_follower_joint.py" "${MOVE_ARGS[@]}"

MOVE_EXIT_CODE=$?
if [ $MOVE_EXIT_CODE -eq 0 ]; then
  echo "✅ follower 单关节控制执行成功！"
else
  echo "❌ follower 单关节控制失败，退出码：$MOVE_EXIT_CODE"
fi

deactivate_lerobot_env
exit $MOVE_EXIT_CODE
