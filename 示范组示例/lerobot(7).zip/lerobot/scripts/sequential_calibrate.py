#!/usr/bin/env python3

from __future__ import annotations

import argparse
import select
import sys
import time
from typing import Iterable

from lerobot.motors import MotorCalibration
from lerobot.motors.feetech import OperatingMode
from lerobot.robots.so_follower.config_so_follower import SOFollowerRobotConfig
from lerobot.robots.so_follower.so_follower import SOFollower
from lerobot.teleoperators.so_leader.config_so_leader import SOLeaderTeleopConfig
from lerobot.teleoperators.so_leader.so_leader import SOLeader


READ_RETRIES = 2
WRITE_RETRIES = 2
POLL_INTERVAL_S = 0.05
FULL_TURN_MOTOR = "wrist_roll"
READ_RETRY_SLEEP_S = 0.03
MAX_CONSECUTIVE_SAMPLE_FAILURES = 20
MIN_REQUIRED_SPAN = 20


def parse_args() -> argparse.Namespace:
    parser = argparse.ArgumentParser(description="Calibrate one SO101 leader/follower arm without sync_read.")
    parser.add_argument("--device-type", choices=("follower", "leader"), required=True)
    parser.add_argument("--port", required=True)
    parser.add_argument("--device-id", required=True)
    return parser.parse_args()


def build_device(args: argparse.Namespace):
    if args.device_type == "follower":
        config = SOFollowerRobotConfig(
            id=args.device_id,
            port=args.port,
            cameras={},
            use_degrees=True,
        )
        return SOFollower(config)

    config = SOLeaderTeleopConfig(
        id=args.device_id,
        port=args.port,
        use_degrees=True,
    )
    return SOLeader(config)


def prompt_existing_calibration(device) -> bool:
    if not device.calibration:
        return False

    user_input = input(
        f"Press ENTER to use provided calibration file associated with the id {device.id}, "
        "or type 'c' and press ENTER to run calibration: "
    )
    return user_input.strip().lower() != "c"


def set_position_mode(device) -> None:
    device.bus.disable_torque(num_retry=WRITE_RETRIES)
    for motor in device.bus.motors:
        device.bus.write(
            "Operating_Mode",
            motor,
            OperatingMode.POSITION.value,
            num_retry=WRITE_RETRIES,
        )


def reset_calibration_sequential(device, motors: Iterable[str]) -> None:
    for motor in motors:
        model = device.bus._get_motor_model(motor)
        max_res = device.bus.model_resolution_table[model] - 1
        device.bus.write("Homing_Offset", motor, 0, normalize=False, num_retry=WRITE_RETRIES)
        device.bus.write("Min_Position_Limit", motor, 0, normalize=False, num_retry=WRITE_RETRIES)
        device.bus.write("Max_Position_Limit", motor, max_res, normalize=False, num_retry=WRITE_RETRIES)
    device.bus.calibration = {}


def read_positions_sequential(device, motors: Iterable[str]) -> dict[str, int]:
    return {
        motor: int(device.bus.read("Present_Position", motor, normalize=False, num_retry=READ_RETRIES))
        for motor in motors
    }


def read_positions_with_recovery(
    device,
    motors: list[str],
    fallback: dict[str, int] | None = None,
) -> tuple[dict[str, int], list[str]]:
    positions: dict[str, int] = {}
    failed: list[str] = []
    fallback = fallback or {}

    for motor in motors:
        value: int | None = None
        for _ in range(READ_RETRIES + 1):
            try:
                value = int(device.bus.read("Present_Position", motor, normalize=False, num_retry=READ_RETRIES))
                break
            except Exception:
                time.sleep(READ_RETRY_SLEEP_S)

        if value is None:
            failed.append(motor)
            if motor in fallback:
                value = fallback[motor]
            else:
                raise ConnectionError(f"Failed to read Present_Position for motor '{motor}' repeatedly.")

        positions[motor] = value

    return positions, failed


def set_half_turn_homings_sequential(device) -> dict[str, int]:
    motor_names = list(device.bus.motors)
    reset_calibration_sequential(device, motor_names)
    positions = read_positions_sequential(device, motor_names)
    homing_offsets = device.bus._get_half_turn_homings(positions)
    for motor, offset in homing_offsets.items():
        device.bus.write("Homing_Offset", motor, int(offset), normalize=False, num_retry=WRITE_RETRIES)
    return {motor: int(offset) for motor, offset in homing_offsets.items()}


def render_ranges(mins: dict[str, int], positions: dict[str, int], maxes: dict[str, int]) -> None:
    print("\033[2J\033[H", end="")
    print("-------------------------------------------")
    print(f"{'NAME':<15} | {'MIN':>6} | {'POS':>6} | {'MAX':>6}")
    for motor in mins:
        print(f"{motor:<15} | {mins[motor]:>6} | {positions[motor]:>6} | {maxes[motor]:>6}")
    print()
    print("Move joints by hand. Press ENTER to stop recording.")
    sys.stdout.flush()


def record_ranges_of_motion_sequential(device, motors: list[str]) -> tuple[dict[str, int], dict[str, int]]:
    mins = read_positions_sequential(device, motors)
    maxes = dict(mins)
    last_positions = dict(mins)
    consecutive_failures = 0

    while True:
        positions, failed = read_positions_with_recovery(device, motors, last_positions)
        if failed:
            consecutive_failures += 1
        else:
            consecutive_failures = 0
        if consecutive_failures >= MAX_CONSECUTIVE_SAMPLE_FAILURES:
            raise ConnectionError(
                "Too many consecutive read failures while recording motion ranges. "
                f"Last failed motors: {failed}"
            )

        mins = {motor: min(mins[motor], positions[motor]) for motor in motors}
        maxes = {motor: max(maxes[motor], positions[motor]) for motor in motors}
        last_positions = dict(positions)
        render_ranges(mins, positions, maxes)
        if failed:
            print(f"Warning: transient read failure on: {', '.join(failed)}")
            sys.stdout.flush()

        ready, _, _ = select.select([sys.stdin], [], [], POLL_INTERVAL_S)
        if ready:
            sys.stdin.readline()
            break

    unchanged = [motor for motor in motors if mins[motor] == maxes[motor]]
    if unchanged:
        raise ValueError(
            "Some motors did not move at all during calibration recording: "
            f"{unchanged}. Make sure you manually sweep every joint, especially the gripper."
        )

    too_small = {
        motor: maxes[motor] - mins[motor]
        for motor in motors
        if (maxes[motor] - mins[motor]) < MIN_REQUIRED_SPAN
    }
    if too_small:
        spans = ", ".join(f"{motor}={span}" for motor, span in too_small.items())
        raise ValueError(
            "Some motors were moved too little during calibration recording: "
            f"{spans}. Sweep each joint much farther before pressing ENTER."
        )

    return mins, maxes


def run_calibration(device) -> None:
    print(f"Running sequential calibration of {device}")
    set_position_mode(device)

    input(f"Move {device} to the middle of its range of motion and press ENTER....")
    homing_offsets = set_half_turn_homings_sequential(device)

    unknown_range_motors = [motor for motor in device.bus.motors if motor != FULL_TURN_MOTOR]
    print(
        f"Move all joints except '{FULL_TURN_MOTOR}' sequentially through their entire ranges of motion.\n"
        "Recording positions. Press ENTER to stop..."
    )
    time.sleep(0.5)
    range_mins, range_maxes = record_ranges_of_motion_sequential(device, unknown_range_motors)
    range_mins[FULL_TURN_MOTOR] = 0
    range_maxes[FULL_TURN_MOTOR] = 4095

    device.calibration = {}
    for motor, motor_meta in device.bus.motors.items():
        device.calibration[motor] = MotorCalibration(
            id=motor_meta.id,
            drive_mode=0,
            homing_offset=homing_offsets[motor],
            range_min=range_mins[motor],
            range_max=range_maxes[motor],
        )

    device.bus.write_calibration(device.calibration)
    device._save_calibration()
    print(f"Calibration saved to {device.calibration_fpath}")


def main() -> int:
    args = parse_args()
    device = build_device(args)
    device.connect(calibrate=False)
    try:
        if prompt_existing_calibration(device):
            print(f"Writing calibration file associated with the id {device.id} to the motors")
            device.bus.write_calibration(device.calibration)
            return 0

        run_calibration(device)
        return 0
    except Exception as exc:
        print(f"Calibration failed: {exc}", file=sys.stderr)
        return 1
    finally:
        try:
            if args.device_type == "follower":
                device.bus.disconnect(False)
            else:
                device.disconnect()
        except Exception as exc:
            print(f"Warning: disconnect encountered an error: {exc}", file=sys.stderr)


if __name__ == "__main__":
    raise SystemExit(main())
