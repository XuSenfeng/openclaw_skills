#!/bin/zsh

# Optional positional arguments:
# 1) follower robot port (default: auto detect)
# 2) leader teleop port (default: auto detect)
ROBOT_PORT_INPUT="${1:-}"
TELEOP_PORT_INPUT="${2:-}"
MAX_RELATIVE_TARGET="${MAX_RELATIVE_TARGET:-10}"
TELEOP_FPS="${TELEOP_FPS:-30}"
TELEOP_TIME_S="${TELEOP_TIME_S:-}"
SCRIPT_PATH="${0:A}"
SCRIPT_DIR="${SCRIPT_PATH:h}"
REPO_ROOT="${SCRIPT_DIR:h}"

source "$SCRIPT_DIR/common.sh"

ROBOT_PORT="$(resolve_port_or_exit follower "$ROBOT_PORT_INPUT")" || exit 1
TELEOP_PORT="$(resolve_port_or_exit leader "$TELEOP_PORT_INPUT")" || exit 1

enter_repo_root
activate_lerobot_env

# ============= 执行自定义 teleoperate 命令 =============
echo "🚀 开始执行顺序读写 teleoperate..."
echo "🔌 使用 follower 端口：$ROBOT_PORT"
echo "🔌 使用 leader 端口：$TELEOP_PORT"
echo "🛡️  follower 单步限幅：$MAX_RELATIVE_TARGET"
echo "⏱️  teleop 帧率：$TELEOP_FPS"
TELEOP_ARGS=(
  --follower-port "$ROBOT_PORT"
  --leader-port "$TELEOP_PORT"
  --fps "$TELEOP_FPS"
  --max-relative-target "$MAX_RELATIVE_TARGET"
)

if [ -n "$TELEOP_TIME_S" ]; then
  TELEOP_ARGS+=(--teleop-time-s "$TELEOP_TIME_S")
fi

python "$SCRIPT_DIR/teleoperate_pair.py" "${TELEOP_ARGS[@]}"

# ============= 执行完成后的清理 =============
TELEOP_EXIT_CODE=$?
if [ $TELEOP_EXIT_CODE -eq 0 ]; then
    echo "✅ teleoperate 执行成功！"
else
    echo "❌ teleoperate 执行失败，退出码：$TELEOP_EXIT_CODE"
fi

deactivate_lerobot_env
exit $TELEOP_EXIT_CODE
