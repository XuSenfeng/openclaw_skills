#!/bin/zsh

# Optional positional arguments:
# 1) follower robot port (default: auto detect)
# 2) leader robot port (default: auto detect)
FOLLOWER_PORT_INPUT="${1:-}"
LEADER_PORT_INPUT="${2:-}"
SCRIPT_PATH="${0:A}"
SCRIPT_DIR="${SCRIPT_PATH:h}"
REPO_ROOT="${SCRIPT_DIR:h}"

source "$SCRIPT_DIR/common.sh"

FOLLOWER_PORT="$(resolve_port_or_exit follower "$FOLLOWER_PORT_INPUT")" || exit 1
LEADER_PORT="$(resolve_port_or_exit leader "$LEADER_PORT_INPUT")" || exit 1

enter_repo_root
activate_lerobot_env

# ============= 校准 follower =============
echo "🛠️ 开始校准 follower 机械臂..."
echo "🔌 follower 端口：$FOLLOWER_PORT"
python3 "$SCRIPT_DIR/sequential_calibrate.py" \
  --device-type follower \
  --port "$FOLLOWER_PORT" \
  --device-id my_awesome_follower_arm

FOLLOWER_EXIT_CODE=$?
if [ $FOLLOWER_EXIT_CODE -ne 0 ]; then
    echo "❌ follower 校准失败，退出码：$FOLLOWER_EXIT_CODE"
    deactivate_lerobot_env
    exit $FOLLOWER_EXIT_CODE
fi

echo "✅ follower 校准完成"

# ============= 校准 leader =============
echo "🛠️ 开始校准 leader 机械臂..."
echo "🔌 leader 端口：$LEADER_PORT"
python3 "$SCRIPT_DIR/sequential_calibrate.py" \
  --device-type leader \
  --port "$LEADER_PORT" \
  --device-id my_awesome_leader_arm

LEADER_EXIT_CODE=$?
if [ $LEADER_EXIT_CODE -eq 0 ]; then
    echo "✅ leader 校准完成"
    echo "✅ 所有机械臂校准成功！"
else
    echo "❌ leader 校准失败，退出码：$LEADER_EXIT_CODE"
fi

deactivate_lerobot_env
exit $LEADER_EXIT_CODE
