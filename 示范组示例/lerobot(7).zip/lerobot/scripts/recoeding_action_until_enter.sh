#!/bin/zsh

# Optional positional arguments:
# 1) dataset prefix (default: so101_try)
# 2) single task text (default: pick and place test)
# 3) follower robot port (default: auto detect)
# 4) leader teleop port (default: auto detect)
DATASET_PREFIX="${1:-so101_try}"
SINGLE_TASK="${2:-pick and place test}"
ROBOT_PORT_INPUT="${3:-}"
TELEOP_PORT_INPUT="${4:-}"
RECORD_FPS="${RECORD_FPS:-15}"
MAX_RELATIVE_TARGET="${MAX_RELATIVE_TARGET:-10}"
DISPLAY_DATA="${DISPLAY_DATA:-false}"
PLAY_SOUNDS="${PLAY_SOUNDS:-false}"
MAX_RECORD_SECONDS="${MAX_RECORD_SECONDS:-86400}"
SCRIPT_PATH="${0:A}"
SCRIPT_DIR="${SCRIPT_PATH:h}"
REPO_ROOT="${SCRIPT_DIR:h}"

source "$SCRIPT_DIR/common.sh"

ROBOT_PORT="$(resolve_port_or_exit follower "$ROBOT_PORT_INPUT")" || exit 1
TELEOP_PORT="$(resolve_port_or_exit leader "$TELEOP_PORT_INPUT")" || exit 1

enter_repo_root
activate_lerobot_env
ensure_data_root

DATASET_NAME="$(next_dataset_name "$DATASET_PREFIX")"
DATASET_REPO_ID="$(dataset_name_to_repo_id "$DATASET_NAME")"
EXPECTED_DATASET_PATH="${REPO_ROOT}/data/${DATASET_NAME}"

echo "🚀 开始执行按 Enter 停止的录制脚本..."
echo "📦 本次数据集名称：$DATASET_NAME"
echo "🆔 数据集标识：$DATASET_REPO_ID"
echo "📁 数据将保存到：$EXPECTED_DATASET_PATH"
echo "🔌 使用 follower 端口：$ROBOT_PORT"
echo "🔌 使用 leader 端口：$TELEOP_PORT"
echo "⏱️  录制帧率：$RECORD_FPS"
echo "🛡️  follower 单步限幅：$MAX_RELATIVE_TARGET"
echo "🖥️  显示实时数据：$DISPLAY_DATA"
echo "⌨️  录制开始后，直接按 Enter 即可停止并保存当前 episode"
echo "⏳ 最大录制时长保护：$MAX_RECORD_SECONDS 秒"

python "$SCRIPT_DIR/record_until_enter.py" \
  --robot.type=so101_follower \
  --robot.port="$ROBOT_PORT" \
  --robot.id=my_awesome_follower_arm \
  --robot.max_relative_target="$MAX_RELATIVE_TARGET" \
  --teleop.type=so101_leader \
  --teleop.port="$TELEOP_PORT" \
  --teleop.id=my_awesome_leader_arm \
  --dataset.repo_id="$DATASET_REPO_ID" \
  --dataset.root="$EXPECTED_DATASET_PATH" \
  --dataset.single_task="$SINGLE_TASK" \
  --dataset.fps="$RECORD_FPS" \
  --dataset.num_episodes=1 \
  --dataset.episode_time_s="$MAX_RECORD_SECONDS" \
  --dataset.reset_time_s=5 \
  --dataset.push_to_hub=false \
  --display_data="$DISPLAY_DATA" \
  --play_sounds="$PLAY_SOUNDS"

RECORD_EXIT_CODE=$?
if [ $RECORD_EXIT_CODE -eq 0 ]; then
  echo "✅ 按 Enter 停止的录制执行成功！"
  if [ -d "$EXPECTED_DATASET_PATH" ]; then
    echo "📁 录制数据目录：$EXPECTED_DATASET_PATH"
  else
    echo "ℹ️ 命令已成功，若未即时看到目录，请检查：$REPO_ROOT/data"
  fi
else
  echo "❌ 录制执行失败，退出码：$RECORD_EXIT_CODE"
fi

deactivate_lerobot_env
exit $RECORD_EXIT_CODE
