#!/bin/zsh

# Optional positional arguments:
# 1) follower robot port (default: auto detect)
# 2) leader teleop port (default: auto detect)
FOLLOWER_PORT_INPUT="${1:-}"
LEADER_PORT_INPUT="${2:-}"
SCRIPT_PATH="${0:A}"
SCRIPT_DIR="${SCRIPT_PATH:h}"
REPO_ROOT="${SCRIPT_DIR:h}"

source "$SCRIPT_DIR/common.sh"

FOLLOWER_PORT="$(resolve_port_or_exit follower "$FOLLOWER_PORT_INPUT")" || exit 1
LEADER_PORT="$(resolve_port_or_exit leader "$LEADER_PORT_INPUT")" || exit 1

enter_repo_root
activate_lerobot_env

python - <<PY
from lerobot.motors import Motor, MotorNormMode
from lerobot.motors.feetech import FeetechMotorsBus

ports = {
    "follower": "${FOLLOWER_PORT}",
    "leader": "${LEADER_PORT}",
}

motors = {
    "shoulder_pan": Motor(1, "sts3215", MotorNormMode.DEGREES),
    "shoulder_lift": Motor(2, "sts3215", MotorNormMode.DEGREES),
    "elbow_flex": Motor(3, "sts3215", MotorNormMode.DEGREES),
    "wrist_flex": Motor(4, "sts3215", MotorNormMode.DEGREES),
    "wrist_roll": Motor(5, "sts3215", MotorNormMode.DEGREES),
    "gripper": Motor(6, "sts3215", MotorNormMode.RANGE_0_100),
}

overall_ok = True

for name, port in ports.items():
    print(f"=== {name}: {port} ===")
    bus = FeetechMotorsBus(port=port, motors=motors)
    try:
        bus.connect(handshake=False)
        ping_result = {i: bus.ping(i) for i in range(1, 7)}
        online = [i for i, model in ping_result.items() if model is not None]
        print("PING", ping_result)
        if len(online) == 6:
            print("STATUS OK")
        else:
            print("STATUS FAIL")
            overall_ok = False
    except Exception as e:
        print("STATUS FAIL")
        print(repr(e))
        overall_ok = False
    finally:
        try:
            bus.disconnect()
        except Exception:
            pass

print(f"OVERALL {'OK' if overall_ok else 'FAIL'}")
raise SystemExit(0 if overall_ok else 1)
PY

PING_EXIT_CODE=$?
deactivate_lerobot_env
exit $PING_EXIT_CODE
