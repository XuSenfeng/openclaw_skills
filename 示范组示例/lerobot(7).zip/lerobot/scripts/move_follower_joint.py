#!/usr/bin/env python3

from __future__ import annotations

import argparse
import time

from lerobot.motors import Motor, MotorNormMode
from lerobot.motors.feetech import FeetechMotorsBus


JOINTS = (
    "shoulder_pan",
    "shoulder_lift",
    "elbow_flex",
    "wrist_flex",
    "wrist_roll",
    "gripper",
)
WRITE_RETRIES = 2
CONNECT_RETRIES = 3
RETRY_SLEEP_S = 0.2


def parse_args():
    parser = argparse.ArgumentParser(description="Move one follower joint while keeping all others fixed.")
    parser.add_argument("--joint", required=True, choices=JOINTS)
    parser.add_argument("--value", required=True, type=float)
    parser.add_argument("--mode", choices=("delta", "target"), default="delta")
    parser.add_argument("--port", required=True)
    parser.add_argument("--robot-id", default="my_awesome_follower_arm")
    parser.add_argument("--max-relative-target", type=float, default=5.0)
    parser.add_argument("--hold-time-s", type=float, default=1.0)
    parser.add_argument("--return-to-start", action="store_true")
    return parser.parse_args()


def build_bus(port: str) -> FeetechMotorsBus:
    motors = {
        "shoulder_pan": Motor(1, "sts3215", MotorNormMode.DEGREES),
        "shoulder_lift": Motor(2, "sts3215", MotorNormMode.DEGREES),
        "elbow_flex": Motor(3, "sts3215", MotorNormMode.DEGREES),
        "wrist_flex": Motor(4, "sts3215", MotorNormMode.DEGREES),
        "wrist_roll": Motor(5, "sts3215", MotorNormMode.DEGREES),
        "gripper": Motor(6, "sts3215", MotorNormMode.RANGE_0_100),
    }
    return FeetechMotorsBus(port, motors)


def format_pose(pose):
    ordered = [f"{joint}={pose[joint]:.3f}" for joint in JOINTS]
    return ", ".join(ordered)


def read_pose(bus: FeetechMotorsBus) -> dict[str, float]:
    return {joint: float(bus.read("Present_Position", joint)) for joint in JOINTS}


def write_joint_target(bus: FeetechMotorsBus, joint: str, value: float) -> None:
    bus.write("Goal_Position", joint, float(value), num_retry=WRITE_RETRIES)


def connect_and_load_calibration(bus: FeetechMotorsBus) -> None:
    last_error: Exception | None = None
    for attempt in range(1, CONNECT_RETRIES + 1):
        try:
            if bus.is_connected:
                bus.disconnect()
            bus.connect(handshake=False)
            bus.calibration = bus.read_calibration()
            return
        except Exception as exc:
            last_error = exc
            try:
                if bus.is_connected:
                    bus.disconnect()
            except Exception:
                pass
            if attempt < CONNECT_RETRIES:
                print(f"RETRY_CONNECT: attempt={attempt} error={exc}", flush=True)
                time.sleep(RETRY_SLEEP_S)
    assert last_error is not None
    raise last_error


def main():
    args = parse_args()
    bus = build_bus(args.port)
    connect_and_load_calibration(bus)
    try:
        base_pose = read_pose(bus)
        print(f"BASE: {format_pose(base_pose)}", flush=True)

        target_pose = dict(base_pose)
        if args.mode == "delta":
            target_pose[args.joint] = base_pose[args.joint] + args.value
        else:
            target_pose[args.joint] = args.value

        print(
            f"MOVE: joint={args.joint} mode={args.mode} requested={target_pose[args.joint]:.3f}",
            flush=True,
        )
        write_joint_target(bus, args.joint, target_pose[args.joint])
        print(f"SENT: {format_pose(target_pose)}", flush=True)

        if args.hold_time_s > 0:
            time.sleep(args.hold_time_s)

        current_pose = read_pose(bus)
        print(f"OBSERVED: {format_pose(current_pose)}", flush=True)

        if args.return_to_start:
            print("RETURN: moving back to starting pose", flush=True)
            write_joint_target(bus, args.joint, base_pose[args.joint])
            print(f"RETURN_SENT: {format_pose(base_pose)}", flush=True)
            if args.hold_time_s > 0:
                time.sleep(args.hold_time_s)
    finally:
        bus.disconnect()
        print("DONE", flush=True)


if __name__ == "__main__":
    main()
