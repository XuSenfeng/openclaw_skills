#!/bin/zsh

ROBOT_PORT_INPUT="${1:-}"
MAX_RELATIVE_TARGET="${MAX_RELATIVE_TARGET:-10}"
SCRIPT_PATH="${0:A}"
SCRIPT_DIR="${SCRIPT_PATH:h}"
REPO_ROOT="${SCRIPT_DIR:h}"

source "$SCRIPT_DIR/common.sh"

ROBOT_PORT="$(resolve_port_or_exit follower "$ROBOT_PORT_INPUT")" || exit 1

enter_repo_root
activate_lerobot_env

python "$SCRIPT_DIR/read_follower_pose.py" \
  --port "$ROBOT_PORT" \
  --max-relative-target "$MAX_RELATIVE_TARGET"

STATE_EXIT_CODE=$?
deactivate_lerobot_env
exit $STATE_EXIT_CODE
