#!/bin/zsh

# Optional positional arguments:
# 1) dataset name or path (default: latest dataset under ./data)
# 2) robot port (default: auto detect)
DATASET_INPUT="${1:-}"
ROBOT_PORT_INPUT="${2:-}"
MAX_RELATIVE_TARGET="${MAX_RELATIVE_TARGET:-10}"
SKIP_DATASET_SANITY_CHECK="${SKIP_DATASET_SANITY_CHECK:-false}"
SCRIPT_PATH="${0:A}"
SCRIPT_DIR="${SCRIPT_PATH:h}"
REPO_ROOT="${SCRIPT_DIR:h}"

source "$SCRIPT_DIR/common.sh"

ROBOT_PORT="$(resolve_port_or_exit follower "$ROBOT_PORT_INPUT")" || exit 1

enter_repo_root
activate_lerobot_env

ensure_data_root

DATASET_PATH_ON_DISK="$(resolve_dataset_root_path "$DATASET_INPUT")" || {
    echo "❌ 错误：未在 $REPO_ROOT/data 下找到可回放的数据集，请先录制动作数据。"
    deactivate_lerobot_env
    exit 1
}
DATASET_NAME="$(dataset_root_path_to_name "$DATASET_PATH_ON_DISK")"
DATASET_REPO_ID="$(dataset_name_to_repo_id "$DATASET_NAME")"

if [ ! -d "$DATASET_PATH_ON_DISK" ]; then
    echo "❌ 错误：数据集目录不存在：$DATASET_PATH_ON_DISK"
    deactivate_lerobot_env
    exit 1
fi

if ! is_lerobot_dataset_dir "$DATASET_PATH_ON_DISK"; then
    echo "❌ 错误：目录不是有效的 LeRobot 数据集：$DATASET_PATH_ON_DISK"
    deactivate_lerobot_env
    exit 1
fi

if [ "$SKIP_DATASET_SANITY_CHECK" != "true" ]; then
    python "$SCRIPT_DIR/check_dataset_health.py" "$DATASET_PATH_ON_DISK"
    HEALTH_EXIT_CODE=$?
    if [ $HEALTH_EXIT_CODE -ne 0 ]; then
        echo "❌ 错误：数据集统计异常，不建议直接回放：$DATASET_PATH_ON_DISK"
        echo "ℹ️ 如确认仍要回放，可临时设置 SKIP_DATASET_SANITY_CHECK=true"
        deactivate_lerobot_env
        exit $HEALTH_EXIT_CODE
    fi
fi

# ============= 执行 lerobot-replay 命令 =============
echo "🚀 开始执行 lerobot-replay..."
echo "📦 使用数据集标识：$DATASET_REPO_ID"
echo "📁 数据集目录：$DATASET_PATH_ON_DISK"
echo "🔌 使用 follower 端口：$ROBOT_PORT"
echo "🛡️  follower 单步限幅：$MAX_RELATIVE_TARGET"
lerobot-replay \
  --robot.type=so101_follower \
    --robot.port="$ROBOT_PORT" \
  --robot.id=my_awesome_follower_arm \
  --robot.max_relative_target="$MAX_RELATIVE_TARGET" \
  --dataset.repo_id="$DATASET_REPO_ID" \
  --dataset.root="$DATASET_PATH_ON_DISK" \
  --dataset.episode=0

# ============= 执行完成后的清理 =============
# 获取命令执行结果
REPLAY_EXIT_CODE=$?
if [ $REPLAY_EXIT_CODE -eq 0 ]; then
    echo "✅ lerobot-replay 执行成功！"
else
    echo "❌ lerobot-replay 执行失败，退出码：$REPLAY_EXIT_CODE"
fi

deactivate_lerobot_env
exit $REPLAY_EXIT_CODE
