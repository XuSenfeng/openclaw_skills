---
name: ROS-limo-car
description: 用于控制 LIMO 机器人的 skill。可获取机器人状态（里程计/定位/激光雷达/电池）、控制运动（前进/后退/转向）、获取地图预览、设置初始位姿、执行单点或多点导航、拍照。通过 limo_ws_client.py 工具脚本调用，所有输出为 JSON 格式。
---

# ROS-limo-car 技能

先读这一条，再做别的：

- 这是本地 skill，不是 agent。
- 不要用 `sessions_spawn`、`agents_list`、subagent、"available agent list" 来调用它。
- 直接执行本 skill 自带脚本 `scripts/ros_limo_car`。
- 如果用户消息里已经给了具体任务，不要先打招呼，不要先说“我来启动这个技能”，直接执行。
- 拍照/地图命令会在 JSON 里返回 `media_ref`，不要再调用 `message` 工具手动发图。
- 不要先回“我将使用 ROS-limo-car skill...”。先执行，最后只汇报结果。
- 拍照类请求的最终回复应携带一次媒体附件；不要让同一张图在工具层和最终回复层各发送一次。
- 发起 `exec` 工具调用的那条 assistant 消息里，不要放任何用户可见文本；直接发 tool call。

## 工具脚本

所有机器人控制都必须通过 skill 自带启动器 `scripts/ros_limo_car` 完成，**输出均为 JSON**，便于 AI 直接解析。

首选固定命令：

```bash
TOOL="$HOME/.openclaw/skills/ROS-limo-car/scripts/ros_limo_car"
```

这个启动器内部已经固定使用 `python3` 调用 `limo_ws_client.py`，不要改成 `python`，也不要改成别的解释器。

只有在排障时，才直接调用底层脚本：

```bash
python3 ~/.openclaw/skills/ROS-limo-car/scripts/limo_ws_client.py get_state
```

## 强约束

只要用户请求“控制机器人 / 拍照 / 导航 / 查机器人状态”，必须遵守：

- 只使用这个 skill 的 `TOOL`
- 不要调用 `feishu_doc`、`feishu_chat`、`feishu_wiki`、`feishu_drive`、`feishu_bitable`
- 不要为了控制机器人去创建飞书表格、文档、记录或其他侧路工具
- 不要用 `python`，只用 skill 启动器或 `python3`
- 多步骤动作时，按顺序执行多个 `TOOL` 命令；前一步失败就停止，不要继续后续动作

如果用户一句话里包含多个动作，例如“后退 -> 转向 -> 拍照”，应该拆成多个 `TOOL` 调用顺序执行，而不是改用别的工具。

---

## 获取小车状态

```bash
$TOOL get_state
```

返回示例：
```json
{
  "success": true,
  "odom": {"x": 0.12, "y": -0.03, "yaw": 5.1, "vx": 0.0, "vyaw": 0.0},
  "amcl": {"x": 0.15, "y": -0.02, "yaw": 4.7, "available": true},
  "scan": {"min_distance": 0.45, "front_distance": 1.2, "left_distance": 0.8, "right_distance": 0.6, "points": 360},
  "status": {"battery_voltage": 12.3, "motion_mode": 0, "motion_mode_name": "差速(diff)", "error_code": 0},
  "connected_clients": 1
}
```

如果 JSON 结果里包含：

```json
{
  "success": true,
  "media_ref": "./.openclaw_media/robot_photo.jpg"
}
```

则最终回复应附带这一个媒体文件，不要让工具输出再单独发一次，也不要重复附带同一路径两次。

---

## 控制运动

```bash
# 前进 0.5 m/s，持续 2 秒
$TOOL move --linear-x 0.5 --duration 2.0

# 后退 0.3 m/s，持续 1.5 秒
$TOOL move --linear-x -0.3 --duration 1.5

# 左转（角速度 1.0 rad/s），持续 1 秒
$TOOL move --angular-z 1.0 --duration 1.0

# 右转同时前进
$TOOL move --linear-x 0.3 --angular-z -0.5 --duration 2.0

# 横向平移（麦轮模式）
$TOOL move --linear-y 0.3 --duration 1.0
```

参数说明：
| 参数 | 含义 | 正值 | 负值 |
|---|---|---|---|
| `--linear-x` | 前后速度 (m/s) | 前进 | 后退 |
| `--angular-z` | 转向角速度 (rad/s) | 左转 | 右转 |
| `--linear-y` | 横向速度 (m/s，仅麦轮) | 左平移 | 右平移 |
| `--duration` | 持续时间 (秒) | — | — |

---

## 原地转向

优先使用 `turn`，不要自己在回复里手算持续时间。

```bash
# 左转 90 度
$TOOL turn --angle-deg 90

# 右转 45 度
$TOOL turn --angle-deg -45

# 指定更慢的转向速度
$TOOL turn --angle-deg 90 --angular-speed 0.3
```

参数说明：

| 参数 | 含义 |
|---|---|
| `--angle-deg` | 旋转角度（度），正=左转，负=右转 |
| `--angle-rad` | 旋转角度（弧度），正=左转，负=右转 |
| `--angular-speed` | 原地旋转角速度，默认 `0.4 rad/s` |

---

## 紧急停车

```bash
$TOOL stop
```

---

## 获取地图预览

这个命令会抓取当前 `/map`，叠加 1 米网格和当前机器人定位箭头，并把地图图片作为附件发回聊天。

```bash
$TOOL get_map
$TOOL get_map --output ./limo_map.png
```

返回里会包含：
- `origin.x / origin.y`：地图原点
- `resolution`：每像素多少米
- `robot_pose`：当前 AMCL 位姿（若已有定位）

给用户发地图时，必须顺手说明这 4 点：
- 地图坐标系是 `map`
- 图中默认 `x` 轴向右增加，`y` 轴向上增加
- 当前预览图带 1 米网格，可以按网格粗略估位置
- 蓝色箭头是机器人当前朝向

推荐用法：
- 先让机器人发一张地图预览到飞书
- 再根据地图里的位置，用下面的 `set_initialpose` 和 `navigate` 发送具体位姿

当用户说“发地图给我选点”时，回复里应明确告诉用户：
- “请按地图上的 1 米网格估算目标点坐标”
- “坐标单位是米”
- “如果你只会看方向，不想算弧度，直接告诉我角度即可，我会用 `--yaw-deg`”

---

## 设置初始位姿

飞书里没有 RViz 的 `2D Pose Estimate` 点击工具，所以这里用命令方式代替。建议优先使用角度制参数 `--yaw-deg`。

```bash
# 在 map 坐标系下把机器人初始位姿设为 (0.2, -0.1)，朝左 90 度
$TOOL set_initialpose --x 0.2 --y -0.1 --yaw-deg 90

# 也可以直接传弧度
$TOOL set_initialpose --x 0.2 --y -0.1 --yaw 1.57
```

说明：
- 该命令会向 `/initialpose` 连续发布 3 次，供 `amcl` 收敛。
- 成功后应再用 `get_state` 或 `get_map` 看 `amcl` 是否稳定。
- 在和用户对话时，默认优先使用角度制解释朝向，只有在用户明确要求时才说弧度。

---

## 坐标与朝向规则

这一段在飞书里非常重要。只要涉及 `set_initialpose` 或 `navigate`，都应该按这个规则解释。

### 坐标怎么对应地图

- 坐标系是 `map`
- 单位是米
- 地图图像里：
  - 向右是 `+x`
  - 向上是 `+y`
- 地图上的每个粗网格约 1 米
- 因此：
  - “右边 2 格、上边 1 格” 大约就是 `x +2m, y +1m`
  - “左下角某点” 就是比当前点 `x` 更小、`y` 更小

如果地图返回了：
- `origin.x = -9.26`
- `origin.y = -6.88`

这表示地图左下区域大致从 `(-9.26, -6.88)` 开始，而不是从 `(0, 0)` 开始。

### 朝向怎么理解

默认对用户使用角度制解释，命令里优先用 `--yaw-deg`。

角度定义：
- `0°`：朝向 `+x`，也就是地图右边
- `90°`：朝向 `+y`，也就是地图上边
- `180°` 或 `-180°`：朝向左边
- `-90°`：朝向下边

常见例子：
- 朝右：`yaw-deg 0`
- 朝上：`yaw-deg 90`
- 朝左：`yaw-deg 180`
- 朝下：`yaw-deg -90`
- 右上：`yaw-deg 45`
- 左上：`yaw-deg 135`

只有在用户明确要求时，才换成弧度：
- `0° = 0 rad`
- `90° = 1.57 rad`
- `180° = 3.14 rad`
- `-90° = -1.57 rad`

### 在飞书里应怎样引导用户

如果用户不知道怎么报点位，应该用这种方式引导：

- “我先发你地图预览。图里向右是 `+x`，向上是 `+y`，每个粗网格约 1 米。”
- “你告诉我目标点大概在地图上的哪一块，例如‘机器人前方右侧 2 米，朝上’，我再帮你换算成坐标。”
- “朝向默认按角度理解：右 `0°`，上 `90°`，左 `180°`，下 `-90°`。”

如果用户直接给自然语言位置，也应先转成明确坐标后再执行，不要模糊执行。

---

## 导航

支持通过 WebSocket 调用 move_base 执行单点导航或多点导航。

单点导航：

```bash
# 导航到 map 坐标系下 (1.0, 0.5)，朝向 1.57 rad
$TOOL navigate --x 1.0 --y 0.5 --yaw 1.57

# 更推荐在聊天里直接用角度制
$TOOL navigate --x 1.0 --y 0.5 --yaw-deg 90

# 指定每个目标点超时时间为 90 秒
$TOOL navigate --x 2.0 --y -0.3 --yaw 0.0 --timeout 90

# 指定导航坐标系
$TOOL navigate --frame map --x 0.0 --y 0.0 --yaw 3.14
```

多点导航：

```bash
$TOOL navigate --waypoints "1.0,0.0,0; 1.0,1.0,1.57; 0.0,0.0,3.14"
```

参数说明：

| 参数 | 含义 |
|---|---|
| `--x` | 单点导航目标 x 坐标 |
| `--y` | 单点导航目标 y 坐标 |
| `--yaw` | 目标朝向，单位 rad，默认 0 |
| `--yaw-deg` | 目标朝向，单位 deg，优先于 `--yaw` |
| `--waypoints` | 多点导航列表，格式为 `"x,y,yaw; x,y,yaw; ..."` |
| `--frame` | 导航目标坐标系，默认 `map` |
| `--timeout` | 每个目标点的超时时间，单位秒，默认 120 |

成功返回示例：

```json
{
  "success": true,
  "message": "导航完成",
  "frame": "map",
  "reached": 3,
  "total": 3
}
```

失败返回示例：

```json
{
  "success": false,
  "error": "导航失败",
  "reached": 1,
  "total": 3,
  "failed_index": 2,
  "status": 4
}
```

说明：

- 单点导航需提供 `--x` 和 `--y`，`--yaw` 可省略
- 多点导航时，`--waypoints` 中每个点都必须是 `x,y,yaw` 三元组
- 实际等待超时会根据目标点数量自动放大，无需手动计算总超时
- 使用前需确保车端导航相关 ROS 节点和 move_base 已正常启动
- 跟用户沟通时，优先把目标朝向表述为角度，例如“朝上 90 度”，再由脚本转换

---


## 获取摄像头图片

```bash
$TOOL get_image
# 指定相机、保存路径和压缩质量
$TOOL get_image --camera cam0 --output ./limo_cam0.jpg --quality 80
$TOOL get_image --camera cam1 --output ./limo_cam1.jpg --quality 80
```

说明：
- 该命令通过 WebSocket 请求服务器，服务器会返回最近一帧 ROS 图像话题的图片（JPEG 格式，base64 编码），并保存到本地。
- 当前机器人实际使用：
  - `cam0 -> /usb_cam_0/image_raw`
  - `cam1 -> /usb_cam_1/image_raw`
- 支持 `--output` 指定保存路径，`--quality` 指定 JPEG 压缩质量（30-95，默认85）。
- 为了让 OpenClaw 能把图片作为附件直接发回聊天，脚本会额外打印一行 `MEDIA:./相对路径`。
- 若你传入的是绝对路径（例如 `/tmp/...`），脚本会自动复制一份到当前工作目录下的 `./.openclaw_media/`，并用相对路径作为附件引用。
- 若长时间未收到图片，请检查小车端 `/usb_cam/image_raw` 话题是否正常发布。

返回示例：
```json
{
  "success": true,
  "message": "已通过 WebSocket 获取图像",
  "local_path": "/tmp/limo_cam.jpg",
  "width": 1280,
  "height": 720,
  "quality": 85,
  "ts": 1710750000.123
}
```

---

## 拍照（通过SSH远程触发）

```bash
$TOOL take_photo
# 或指定相机与本地保存路径
$TOOL take_photo --camera cam0 --output ./limo_photo_cam0.jpg
$TOOL take_photo --camera cam1 --output ./limo_photo_cam1.jpg
```

返回：
```json
{"success": true, "local_path": "/tmp/limo_photo.jpg", "remote_path": "/home/agilex/Desktop/color_photo_fixed.jpg"}
```

说明：
- 现在 `take_photo` 与 `get_image` 一样，都是直接从 ROS 图像话题抓取当前帧，不再依赖旧的远端拍照脚本。
- 在 OpenClaw 聊天渠道里，图片会通过脚本输出的 `MEDIA:` 行自动作为附件发送，不再只回一段本地路径文本。
- 调用这两个命令后，不要再额外手动调用 `openclaw message send` 发送图片；正常返回一段简短说明即可，OpenClaw 会自动附带图片。

## 多步骤动作模板

当用户说：
- “后退 0.1m/s 三秒，左转 90 度，然后拍照给我”

应该按这个顺序执行：

```bash
$TOOL move --linear-x -0.1 --duration 3
$TOOL turn --angle-deg 90
$TOOL take_photo --camera cam0 --output ./.openclaw_media/limo_after_turn.jpg
```

执行规则：
- 每一步都检查 JSON 里的 `success`
- 任一步失败就停止并汇报失败点
- 拍照默认用 `cam0`，除非用户明确指定 `cam1`

拍照成功后，使用以下方式查看图片：

```bash
# 在终端预览（需 imgcat，适用于 iTerm2）
imgcat /tmp/limo_photo.jpg

# 用系统默认应用打开
open /tmp/limo_photo.jpg

# 若使用了自定义路径，替换为对应路径
open <local_path>
```

AI 处理图片时，可直接将 `local_path` 作为图片文件路径传入图像分析工具。


---

## 连接配置

默认连接参数（无需手动指定）：
- WebSocket：`ws://10.110.58.254:8765`
- SSH：`agilex@10.110.58.254`（密码 `agx`）

如需更改：
```bash
$TOOL --host <IP> --port <PORT> get_state
$TOOL --host <IP> take_photo --ssh-host <SSH_IP>
```

### 环境启动

在连接到小车的终端上，需先启动 ROS 节点和 WebSocket 服务：

建图：

```bash
roslaunch limo_bringup limo_start.launch
roslaunch limo_bringup limo_teletop_keyboard.launch
# 建图
roslaunch limo_bringup limo_cartographer.launch
# 记录地图
rosrun map_server map_saver -f ~/maps/limo_map
```

导航：

```bash
roslaunch limo_bringup limo_start.launch
rosrun map_server map_server ~/maps/limo_map.yaml
# 需要在有屏幕的地方
roslaunch limo_bringup limo_navigation_diff.launch
```

控制服务器:

```bash
python3 limo_ws_server.py
```

说明：

- 建图阶段先启动底盘，再启动键盘遥控，随后运行 cartographer 进行环境建图
- 保存地图后，导航阶段需要先加载对应的地图 yaml 文件
- `limo_navigation_diff.launch` 需要图形界面环境，因此需要在有屏幕的地方启动
- 实际启动服务之前需要查看是否已经启动了相关的 ROS 节点，特别是 move_base 和 WebSocket 服务节点

---

## 注意事项

- 使用前确保 ROS 节点已在小车上启动（WebSocket 服务运行在 8765 端口）
- 激光雷达 `scan.front_distance` 单位为米，可用于避障判断
- `status.error_code != 0` 时表示小车存在故障
- 当前双路相机按普通 RGB 图像使用：
  - `cam0 -> /usb_cam_0/image_raw`
  - `cam1 -> /usb_cam_1/image_raw`
- 飞书里没有 RViz 点选，因此推荐流程是：
  1. `get_map`
  2. `set_initialpose`
  3. `navigate`
- 每次发地图预览后，都应该顺手解释：
  - 向右是 `+x`
  - 向上是 `+y`
  - 角度默认用度数，不是弧度
  - `0°` 右，`90°` 上，`180°` 左，`-90°` 下
